/*
 * File: LinkExtractor.java
 * Project: LinkExtraction
 * Created: May 23, 2006
 *
 * Copyright 2004 Fabio Gonzalez - National University Colombia 
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained.  
 */


import org.htmlparser.NodeFilter;
import org.htmlparser.Parser;
import org.htmlparser.filters.NodeClassFilter;
import org.htmlparser.parserapplications.StringExtractor;
import org.htmlparser.tags.LinkTag;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;
import org.htmlparser.util.Translate;
public class ProcessHtml {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String url;
		Parser parser;
		NodeFilter filter;
		NodeList list;
		url = args[0];
		filter = new NodeClassFilter(LinkTag.class);
		try {
			parser = new Parser(url);
			list = parser.extractAllNodesThatMatch(filter);
			//Extrae links
			for (int i = 0; i < list.size(); i++){
				LinkTag node = (LinkTag) list.elementAt(i);
				System.out.println("link:"+node.extractLink());
				System.out.println("text:"+Translate.decode(node.getLinkText()));
			}
			//Extrae el texto
			StringExtractor strExt = new StringExtractor(url);
			System.out.println("***************************************");
			System.out.println(Translate.decode(strExt.extractStrings(false)));
		} catch (ParserException e) {
			e.printStackTrace();
		}
		System.exit(0);

	}

}
