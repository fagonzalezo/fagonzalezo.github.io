/*
 * File: FlipperDemo.java
 * Project: AimaFlipper
 * Created: May 30, 2006
 *
 * Copyright 2004 Fabio Gonzalez - National University Colombia 
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained.  
 */
 
package flipper.search;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import aima.search.framework.GoalTest;
import aima.search.framework.GraphSearch;
import aima.search.framework.QueueSearch;
import aima.search.framework.SearchAgent;
import aima.search.framework.Successor;
import aima.search.framework.SuccessorFunction;
import aima.search.framework.Problem;
import aima.search.framework.Search;
import aima.search.uninformed.BreadthFirstSearch;
import aima.search.uninformed.DepthLimitedSearch;
import aima.search.uninformed.IterativeDeepeningSearch;

public class FlipperDemo {
	public static void main(String[] args) {
		FlipperDLSDemo();
		FlipperIDLSDemo();
		FlipperBFSDemo();
	}

	private static void FlipperDLSDemo() {
		System.out.println("\nFlipper recursive DLS -->");
		try {
			Problem problem = new Problem(new FlipperBoard(),
					new FlipperSucessor(),
					new FlipperGoalTest());
			Search search = new DepthLimitedSearch(9);
			SearchAgent agent = new SearchAgent(problem, search);
			printActions(agent.getActions());
			printInstrumentation(agent.getInstrumentation());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void FlipperIDLSDemo() {
		System.out.println("\nFlipper Iterative DLS -->");
		try {
			Problem problem = new Problem(new FlipperBoard(),
					new FlipperSucessor(),
					new FlipperGoalTest());
			Search search = new IterativeDeepeningSearch();
			SearchAgent agent = new SearchAgent(problem, search);
			printActions(agent.getActions());
			printInstrumentation(agent.getInstrumentation());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	private static void FlipperBFSDemo() {
		System.out.println("\nFlipper Breadth First Search -->");
		try {
			Problem problem = new Problem(new FlipperBoard(),
					new FlipperSucessor(),
					new FlipperGoalTest());
			Search search = new BreadthFirstSearch(new GraphSearch());
			SearchAgent agent = new SearchAgent(problem, search);
			printActions(agent.getActions());
			printInstrumentation(agent.getInstrumentation());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	private static void printInstrumentation(Properties properties) {
		Iterator keys = properties.keySet().iterator();
		while (keys.hasNext()) {
			String key = (String) keys.next();
			String property = properties.getProperty(key);
			System.out.println(key + " : " + property);
		}

	}

	private static void printActions(List actions) {
		for (int i = 0; i < actions.size(); i++) {
			String action = (String) actions.get(i);
			System.out.println(action);
		}
	}

}

class FlipperSucessor implements SuccessorFunction{

	public List getSuccessors(Object arg0) {
		ArrayList result = new ArrayList();
		
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				FlipperBoard state = new FlipperBoard();
				state.setBoard((FlipperBoard)arg0);
				state.hit(i,j);
				result.add(new Successor("("+i+","+j+")",state));
			}
		}
		return result;
	}	
}

class FlipperGoalTest implements GoalTest{

	public boolean isGoalState(Object arg0) {
		return arg0.equals(
				new FlipperBoard(
						new boolean[][]{{false,false,false},
										{false,true,false},
										{false,false,false}}));
	}
	
}
