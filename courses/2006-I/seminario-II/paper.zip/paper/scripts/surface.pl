#!/usr/bin/perl -w

$result="";
for($i=1;$i<=4;$i++){
  open(DATA,"<exp$i.dat");
  $linea = <DATA>;
  chomp $linea;
  $factor = substr($linea,1);
  $j=0;
  while ($linea=<DATA>){
    chomp $linea;
    $result .= "$factor $linea  ";
    $j++;
  }
  $result .= "\n";
  close(DATA);
  if ($j != 0){ 
    $numDat=$j;
  }
}

print "SURF 4 $numDat \n",$result;
