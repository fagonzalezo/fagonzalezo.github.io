#!/usr/bin/perl -w


$file = $ARGV[0];

open(DATA,"<$file");
$linea = <DATA>;
chomp $linea;
$factor = substr($linea,1);
close(DATA);

open(GNPFILE,">/tmp/plot.gnp");
print GNPFILE <<end;

set term post eps
set xlabel "Num data"
set ylabel "Time"
set title "Load Factor = $factor"
set out '$file.eps'
plot "$file" notitle with lines

end

close(GNPFILE);
`gnuplot < /tmp/plot.gnp`;
`rm /tmp/plot.gnp`;

