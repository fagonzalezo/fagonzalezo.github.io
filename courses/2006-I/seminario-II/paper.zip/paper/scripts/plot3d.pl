#!/usr/bin/perl -w

$surfFile = $ARGV[0];
open(SCRIPT,">/tmp/surf.dg");

print SCRIPT <<END;
dataplot("$surfFile",title="Hash Table Performance",scaling=UNCONSTRAINED,axes=BOXED,labels=["Load Factor","Num Data", "Time"],labelfont=[HELVETICA,BOLD,12],orientation=[225,70]);
savegraph(cps,"$surfFile.ps");
END

close(SCRIPT);

system("dynagraph < /tmp/surf.dg");
system("rm /tmp/surf.dg");
