#!/usr/bin/perl -w


$maxRuns = $ARGV[0];
$step = $ARGV[1];
$loadFactor = $ARGV[2];

$initSize = 1000;

$classes = "java";

print "#",$loadFactor,"\n";

for($i=0;$i<$maxRuns;$i+=$step){
  $result = `/usr/bin/time -p  java -cp $classes FreeMem $i $initSize $loadFactor 2>&1`;
  @timeOut = split(' ',$result);
  $time = $timeOut[3]+$timeOut[5];
  print $i," ",$time,"\n";
}
