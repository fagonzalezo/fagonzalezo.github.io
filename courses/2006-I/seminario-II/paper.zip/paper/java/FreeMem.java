

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.util.*;

public class FreeMem {
  public static void main(String[] args) {
    int numData = Integer.parseInt(args[0]);
    int initSize = Integer.parseInt(args[1]);
    float loadFactor = Float.parseFloat(args[2]);

    Hashtable ht = new Hashtable(initSize,loadFactor);
    for (int i=0 ;i<numData;i++ ) {
        ht.put(new Integer(i),new Integer((int)Math.rint(30000)));
    }
  }
}
