/*
 * Created on Mar 11, 2004
 *
 */
package flipper.search;

import java.util.ArrayList;

import aima.search.DepthFirstSearchFunction;
import aima.search.Node;
import aima.search.Problem;
import aima.search.SearchAgent;
import aima.search.SearchFunction;

/**
 * Agente de busqueda para flipper
 *  @author Fabio Gonzalez
 *  @date Mar 11, 2004 
 */
public class FlipperSearchAgent extends SearchAgent {

/**
 * Crea un agente de busqueda con un estado inicial dado 
 * @param configuration estado inicial del tablero
 */
	public FlipperSearchAgent(boolean [][] configuration){
		setProblem(new FlipperProblem(configuration));
	 	setSearchFunction(new DepthFirstSearchFunction(10));
		setUp();
	}

/**
 * Crea un agente de busqueda con parametros dados
 * @param depthOfSearch profundidad de busqueda
 * @param p problema
 * @param f funcion de busqueda
 */
	public FlipperSearchAgent(int depthOfSearch,Problem p,SearchFunction f){
		setProblem(p);
		setSearchFunction(f);
		setUp();
	}
	
/**
 * Crea la lista de acciones a partir de un camino (lista de nodos)
 * @param nodes lista de nodos que componen un camino
 */
	public ArrayList nodesToActions(ArrayList nodes) {
		ArrayList retVal= new ArrayList();
		if (nodes.size() > 0){
//			nodes.remove(0); //remove initial state node
			for (int i=0;i<nodes.size();i++){
				Node n = (Node)nodes.get(i);
			   FlipperBoard board = (FlipperBoard)n.getState();
				 retVal.add(board.toString());
			}
		}
		return retVal;
	}

}
