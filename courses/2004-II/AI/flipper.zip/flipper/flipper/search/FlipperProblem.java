/*
 * Created on Mar 11, 2004
 *
 */
package flipper.search;

import java.util.ArrayList;

import aima.search.Problem;


/**
 * Definicion del problema para el rompecabezas Flipper
 *  @author Fabio Gonzalez
 *  @date Mar 11, 2004 
 */
public class FlipperProblem extends Problem {

	/**
	 * Crea una instancia a partir de  un tablero
	 * @param configuration matriz conteniendo la configuracion del tablero
	 */
	public FlipperProblem(boolean[][] configuration) {
		setInitialState(new FlipperBoard(configuration));
	}

	
	/**
	 * Retorna el conjunto de estados accesibles desde un estado dado
	 * @param arg0 estado inicial 
	 */
	public ArrayList getReachableStatesFrom(Object arg0) {
		ArrayList result = new ArrayList();
		
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				FlipperBoard state = new FlipperBoard();
				state.setBoard((FlipperBoard)arg0);
				state.hit(i,j);
				result.add(state);
			}
		}
		return result;
	}

	/**
	 * Determina si un estado dado es objetivo o no
	 * @param arg0 estado a evaluar
	 */
	public boolean isGoalState(Object arg0) {
		
		return arg0.equals(new FlipperBoard(new boolean[][]
			{{false,false,false},{false,true,false},
				{false,false,false}}));
	}

}
