/*
 * Created on Mar 11, 2004
 *
 */
package flipper.search;

import aima.search.BreadthFirstSearchFunction;
import aima.search.InstrumentedProblem;
import aima.search.IterativeDepthFirstSearchFunction;

/**
 * Sirve como base para probar la busqueda 
 *  @author Fabio Gonzalez
 *  @date Mar 11, 2004 
 */
public class Demo {

/**
 * Crea un instancia del problema y ejecuta una busqueda
 * @param args
 */
	public static void main(String[] args) {
		FlipperProblem p = new FlipperProblem(new boolean[][]
			{{true,false,false},{true,true,false},{false,false,false}});
		InstrumentedProblem ip  = new InstrumentedProblem(p);
		FlipperSearchAgent a = new FlipperSearchAgent(15,ip,new IterativeDepthFirstSearchFunction(15));
		//FlipperSearchAgent a = new FlipperSearchAgent(9,ip,new BreadthFirstSearchFunction(6));
		a.printActions();
		ip.printStats();
	}
}

