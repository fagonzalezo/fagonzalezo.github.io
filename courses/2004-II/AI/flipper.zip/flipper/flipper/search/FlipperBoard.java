package flipper.search;
/**
 * Representa un tablero de Flipper
 * @author Fabio Gonzalez
 * @version 1.0
 */

public class FlipperBoard {
	/**
	 * representa la coordenada X del ultimo movimiento 
	 */
	int x=-1;
	
	/**
	 * representa la coordenada X del ultimo movimiento
	 */
	int y=-1;

 /**
  * Representa el estado del tablero
  */
  boolean[][] board;
  /**
   * Constructor
   */
  public FlipperBoard() {
    board = new boolean[][]{{false,false,false},{false,false,false},
        {false,false,false}};
  }

/**
 * crea un tablero a partir de un estado dado
 * @param b estado
 */
  public FlipperBoard(boolean[][] b){
    board = b;
  }

/**
 * cambia el estado de una casilla
 * @param i fila
 * @param j columna
 */
  private void flip(int i,int j){
    board[i][j] = !board[i][j];
  }

/**
 * Simula el efecto de presionar una casilla modificando su estado y el de las casillas
 *  circundantes
 * @param i fila
 * @param j columna
 */
  public void hit(int i,int j){
  	x=i;y=j;
    flip(i,j);
    if (i == 1) {
      flip(0, j);
      flip(2, j);
    }
    if (j == 1) {
      flip(i, 0);
      flip(i, 2);
    }
    if (i != 1 && j != 1) {
      flip(i, 1);
      flip(1, j);
    }
  }
  
  /**
   * Crea una copia de un tablero existente
   * @param aBoard tablero original
   */
  public void setBoard(FlipperBoard aBoard){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
  			board[i][j]=aBoard.board[i][j];
			}
		}
  }
  
  /**
   * compara el tablero contra otro tablero para determinar si tienen el mismo
   * contenido
   * @param o tablero a ser comparado
   */
  public boolean equals(Object o){
  	boolean retval = true;
  	FlipperBoard fb = (FlipperBoard) o;
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if (board[i][j] != fb.board[i][j]){
					retval = false;
					break;
				}
			}
		}
		return retval;	
	}
	
/**
 * returna la ultima accion
 * @return ultima accion en formato String
 */	
	public String getLastAction(){
		return "("+x+","+y+")";
	}

/**
 * retorna la representacion en caracteres ASCII del tablero
 */	
	public String toString(){
		String result = "---("+x+","+y+")\n";
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				result+=board[i][j]?'X':'*';
			}
			result+='\n';
		}
		result+="---";
		return result;
	}
}
