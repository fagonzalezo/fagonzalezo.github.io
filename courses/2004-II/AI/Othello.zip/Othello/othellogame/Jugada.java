/*
 * Project: Othello
 * File: Jugada.java
 * Created on Mar 31, 2004
 *
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained.  
 */
 
package othellogame;

import java.io.Serializable;




/**
 * Representa una jugada especificada por la posicion correspondiente del 
 * tablero.
 * @author Fabio Gonzalez
 *
 */
public class Jugada implements Serializable{
	
	/**
	 * Representa la fila de la jugada.
	 */
	public int x;
	
	/**
	 * Representa la columna de la jugada.
	 */
	public int y;
	
	/**
	 * Crea una instancia con los valores correspondientes.
	 * @param xx fila de la jugada
	 * @param yy coloumna de la jugada
	 */
	public Jugada(int xx,int yy){
		x=xx;
		y=yy;
	}
	/**
	 * @return reopresentacion de la jugada como un string.
	 */
	public String toString(){
		return "("+x+","+y+")";
	}
}
