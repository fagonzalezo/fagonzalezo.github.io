/*
 * Project: Othello
 * File:    Agenteothello.java
 * Created on Mar 31, 2004
 * 
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * MODIFICADO POR JOHANN CAMILO OLARTE DIAZ 
 * COD 256379
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */
 
package othellogame;
import javax.swing.JOptionPane;
/**
 *  Esta clase sirve como base para escribir su propio codigo. Esta clase es 
 * la unica clase que, en principio, se debe modificar.
 *  @author Fabio Gonzalez,JOHANN CAMILO OLARTE DIAZ
 *  @date Mar 31, 2004 
 */
public class Agenteothello {
	
	/**
	 * Efectua la jugada del agente basada en el estado actual del tablero. <br> 
	 * Tenga en cuenta que el tablero tiene la informacion sobre la ficha 
	 * que esta jugando actualmente. <b>Aqui debe ir su codigo</b>. 
	 * @param tab objeto representando el estado actual del tablero
	 * @return La jugada a efectuar.
	 */
	public Jugada calculaJugada(TableroModel tab){

		String valor;
		int i=0;
		int j=0;
	
		valor=JOptionPane.showInputDialog(null,"Turno no"+tab.getTurno()+"\nIntroduzca la fila");
		i=Integer.parseInt(valor);
		valor=JOptionPane.showInputDialog(null,"Turno no"+tab.getTurno()+"\nIntroduzca la columna");
		j=Integer.parseInt(valor);
		return new Jugada(i,j);
}

}//fin de la clase