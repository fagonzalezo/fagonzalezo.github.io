/*
 * Project: Othello
 * File:    ServidorListener.java
 * Created on Mar 29, 2004
 * 
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */
 
package othellogame;

/**
 * @author fgonza
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface ConnListener {
	public void nuevaConexion(String name);
	public void removerConexion(String name);	
}
