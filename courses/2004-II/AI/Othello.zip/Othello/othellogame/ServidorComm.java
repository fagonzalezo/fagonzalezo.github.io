/*
 * Project: Othello
 * File:    ServidorConn.java
 * Created on Mar 29, 2004
 * 
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */
package othellogame;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/**
 *  Maneja las comunicaciones para el servidor. Mantiene una lista de todas
 * las conexiones activas. Provee una interfaz que hace la comunicacion
 * transparente. 
 *  @author Fabio Gonzalez
 */
public class ServidorComm implements Runnable{
	private Socket socket;
	private HashMap conexiones = new HashMap();
	private HashSet listeners = new HashSet();
	public static final int PORT=9000;
	public void arrancarServidor() throws IOException {
		new Thread(this).start();
	}
	private void escuchar() throws IOException{
		ServerSocket s = new ServerSocket(PORT);
		System.out.println("Server Started");
		try {
			while (true) {
				// Blocks until a connection occurs:
				Socket socket = s.accept();
				try {
					ServeOne conexion = new ServeOne(socket);
					String nombre = conexion.getNombre();
					conexiones.put(nombre,conexion);
					Iterator iter = listeners.iterator();
					while (iter.hasNext()) {
						ConnListener element = (ConnListener) iter.next();
						element.nuevaConexion(nombre);
					}					
				} catch (IOException e) {
					// If it fails, close the socket,
					// otherwise the thread will close it:
					socket.close();
				}
			}
		} finally {
			s.close();
		}		
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		try {
			escuchar();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	public void addConnListener(ConnListener listener){
		listeners.add(listener);
	}
	public void removeConnListener(ConnListener listener){
		listeners.remove(listener);
	}
	public Jugada obtenerJugadaSiguiente(String nomJugador,TableroModel tablero){
		ServeOne conexion = (ServeOne) conexiones.get(nomJugador);
		return conexion.jugar(tablero);
	}

	public static void main(String[] args) {
		try {
			ServidorComm servidor = new ServidorComm();
			servidor.arrancarServidor();
			servidor.addConnListener(new TestServidorComm());
			BufferedReader in = new BufferedReader(
				new InputStreamReader(System.in));
			in.readLine();
//			servidor.obtenerJugadaSiguiente("hola");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

class ServeOne{
	private Socket socket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private String nombre;
	public ServeOne(Socket s)
	  throws IOException {
		socket = s;
		out = new ObjectOutputStream(
							socket.getOutputStream());
		out.flush();
		in = new ObjectInputStream(
						socket.getInputStream());
		obtieneNombre();
	}

	private void obtieneNombre() throws IOException {
			String str = null;
			try {
				str = (String) in.readObject();
			} catch (ClassNotFoundException e) {
				System.err.println("ServerOne: Objeto leido no es instancia de String");
				e.printStackTrace();
			}
			nombre = str;
	}
	
	public String getNombre(){
		return nombre;
	}
	
	public Jugada jugar(TableroModel tablero){
		
		try {
			//System.out.println(tablero.toString());
			out.writeObject(new TableroModel(tablero));
			out.flush();
			Jugada jug = (Jugada) in.readObject();
			//System.out.println("Jugada:" + jug);
			return jug;
		} catch (IOException e) {
			System.err.println("ServeOne:error comunicandose con el cliente");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.err.println("ServeOne:error con el objeto recibido");
			e.printStackTrace();
		} 
		return null;
	}
}

class TestServidorComm implements ConnListener{

	/* (non-Javadoc)
	 * @see linea5.ConnListener#nuevaConexion(java.lang.String)
	 */
	public void nuevaConexion(String name) {
		System.out.println("Nueva conexi�n desde:" + name + "\n");		
	}

	/* (non-Javadoc)
	 * @see linea5.ConnListener#removerConexion(java.lang.String)
	 */
	public void removerConexion(String name) {
		
	}
	
}