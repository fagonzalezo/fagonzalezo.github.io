/*
 * Project: Othello
 * File:    Agenteothello.java
 * Created on Mar 31, 2004
 * 
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */


package othellogame;
import javax.swing.JOptionPane;

/*
 * Project: Othello
 * File:    TableroModel.java
 * Created on Mar 27, 2004
 *
 * Copyright 2004 Fabio Gonzalez, Daniel Penagos
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */

import java.io.Serializable;


/**
 * Representacion logica del tablero
 *  @author JOHANN CAMILO OLARTE DIAZ, Fabio Gonzalez
 *  @date Mar 27, 2004 
 */
public class TableroModel implements Serializable{
	/**
	 * Constante que representa una casilla del jugador ROJO
	 */
	public static final int ROJO =  1;
	/**
	 * Constante que representa una casilla del jugador AZUL
	 */	
	public static final int AZUL = -1;
	/**
	 * Constante que representa una casilla vacia
	 */
	public static final int VACIO =  0;
	/**
	 * Recuerda si el ?ltimo turno paso jugadas
	 */
	protected boolean paso;
	/**
	 * Cantidad de fichas rojas en el tablero
	 * Solo est? actualizado luego de utilizar la funcion jugar
	 */
	protected int cantrojas;
	/**
	 * Cantidad de fichas azules en el tablero
	 * Solo est? actualizado luego de utilizar la funcion jugar
	 */
	protected int cantazules;
	/**
	 * Cantidad de vacios en el tablero
	 * Solo est? actualizado luego de utilizar la funcion jugar
	 */
	protected int cantvacios;
	/**
	 * La jugada se ejecuto correctamente (no hubo un ganador)
	 */
	public static final int OK = 0;
	/**
	 * Se jugo en una posicion invalida.
	 */
	public static final int JUGADA_INVALIDA = -1;
	/**
	 * Gano el jugador 1.
	 */
	public static final int GANA_JUGADOR_1 = 1;
	/**
	 * Gano el jugador 2.
	 */
	public static final int GANA_JUGADOR_2 = 2;
	/**
	 * Gano el jugador 2.
	*/
	public static final int EMPATE = 3;
	/**
	 * Representacion del tablero como una matriz.
	 */
	protected int[][] tab;
	/**
	 * Numero del jugador que le corresponde jugar en la siguiente jugada.
	 */
	protected int turno;
	
	/**
	 *Coordenada de la ultima jugada 
	 */
	protected Jugada ultJugada=new Jugada(-2,-2);
	
	/**
	 *Arreglo que guarda las posibles direcciones hacia donde se puede mover  
	 * */
	protected boolean direccion[] = 
		{false, false, false, false, false, false, false, false};
	/**
	 * Direcciones posibles hacia donde se pueden voltear fichas
	 */
	protected final int UPPER = 0;
	protected final int LOWER = 1;
	protected final int RIGHT = 2;
	protected final int LEFT  = 3;
	protected final int UPPERLEFT = 4;
	protected final int UPPERRIGHT = 5;
	protected final int LOWERRIGHT = 6; 
	protected final int LOWERLEFT	= 7;
	
	/**
	 * Copy constructor. Crea una nueva instancia de la clase con los mismos
	 * datos de la instancia parametro.
	 * @param otrotab instancia a ser copiada.
	 */
	public TableroModel(TableroModel otrotab){
		ultJugada=otrotab.ultJugada;
		turno=otrotab.turno;
		paso=otrotab.paso;
		cantrojas=otrotab.cantrojas;
		cantazules=otrotab.cantazules;
		cantvacios=otrotab.cantvacios;
		tab = new int[8][8];
		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++){
				tab[i][j]=otrotab.tab[i][j];
			}
		}
	}
	
	/** Constructor inicial
	 * @param turno_inicial el jugador que va a jugar primero
	 */
	public TableroModel(int turno_inicial){
		if (turno_inicial!=AZUL && turno_inicial!=ROJO){
			System.err.println("TableroModel: argumento erroneo:" + turno_inicial);
		}
		paso=false;
		cantrojas=0;
		cantazules=0;
		cantvacios=0;
		turno=turno_inicial;
		tab = new int[8][8];
		tab[3][3]=ROJO;
		tab[4][4]=ROJO;
		tab[4][3]=AZUL;
		tab[3][4]=AZUL;
	}
		
	/**
	 * Pone un valor en el tablero sin validar y sin efectuar la 
	 * actualizacion del tablero 
	 * @param x fila 
	 * @param y columna
	 * @param who valor a guardar (ROJO, AZUL )
	 */
	
	protected void set(int x, int y, int who){
		tab[x][y]=who;
	}

	/**
	 * Limpia el tablero 
	 */
	
	synchronized public void clear() {
		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++){
				tab[i][j]=VACIO;
			}
		}
		paso=false;
		tab[3][3]=ROJO;
		tab[4][4]=ROJO;
		tab[4][3]=AZUL;
		tab[3][4]=AZUL;
		turno=ROJO;
	}

	/**
	 * Obtiene el valor almacenado en una posicion del tablero
	 * @param x fila 
	 * @param y columna
	 * @return valor almacenado (0 -> vacio, 1 -> jugador 1, 2 -> jugador 2)
	 */
	synchronized public int get(int x,int y){
		return tab[x][y];
	}

	/** 
	 * @return el numero de l jugador que le corresponde jugar en la
	 * siguiente jugada.
	 */
	
	synchronized public int getTurno() {
		return turno;
	}
	
	/** 
	 * retorna la ultima jugada
	 * @return la ultima jugada realizada (Jugada(-2,-2) significa que no hay
	 * jugada previa)
	 */
	synchronized public Jugada getUltimaJugada() {
		return ultJugada;
	}
	
	
	/**
	 * Ejecuta una jugada poniendo una ficha del jugador con el turno 
	 * (<code> turno </code>).
	 * @param jugada
	 */
	synchronized public int  jugar(Jugada jugada) {
		return jugar(jugada.x,jugada.y);		
	}

	/**
	 * Validar jugada recibe las coordenadas de la jugada a realizar
	 * y retorna si dicha jugada es v?lida o no, actualizando la
	 * arreglo de direcciones posibles a las cuales se pueden voltear
	 * fichas 
	 * @param fila fila del tablero indicada para jugar
	 * @param columna columna del tablero indicada para jugar 
	 */	
	synchronized public boolean  validarjugada(int fila,int columna) {
		int i, j;
       
		for (i = 0; i < 8; i++){
		  direccion[i] = false;
		}
		    
		if(tab[fila][columna] != 0) {
		  //la posici?n ya est? ocupada
		  return false;
		} else { 
		  //revisa cada una de las direcciones posibles a jugar y la marca
		  //para luego voltearlas
			
		  if (fila > 1 && tab[fila-1][columna] == -turno) {
			for (i = fila-2; i > 0 && tab[i][columna] == -turno; i--);
			if (tab[i][columna] == turno) {
				direccion[UPPER] = true;	
			}
		  }
		  
		  if (fila < 6 && tab[fila+1][columna] == -turno) {
			for (i = fila+2; i < 7 && tab[i][columna] == -turno; i++);
			if (tab[i][columna] == turno) {
				direccion[LOWER] = true;
			}
		  } 
		  
		  if (columna > 1 && tab[fila][columna-1] == -turno) {
			for (j = columna-2; j > 0 && tab[fila][j] == -turno; j--);
			if (tab[fila][j] == turno) {
				direccion[LEFT] = true;
			}
		  }
		  
		  if (columna < 6 && tab[fila][columna+1] == -turno) {
			for (j = columna+2; j < 7 && tab[fila][j] == -turno; j++);
			if (tab[fila][j] == turno) {
				direccion[RIGHT] = true;
			}
		  }
		  
		  if (fila > 1 && columna > 1 && tab[fila-1][columna-1] == -turno) {
			for (i = fila-2, j = columna-2; i > 0 && j > 0  && tab[i][j] == -turno; i--, j--);
			if (tab[i][j] == turno) {
				direccion[UPPERLEFT] = true;
			}
		  }
		  
		  if (fila < 6 && columna > 1 && tab[fila+1][columna-1] == -turno) {
			for (i = fila+2, j = columna-2; i < 7 && j > 0 && tab[i][j] == -turno; i++, j--);
			if (tab[i][j] == turno) {
				direccion[LOWERLEFT] = true;
			}
		  }

		  if (fila < 6 && columna < 6 && tab[fila+1][columna+1] == -turno) {
			for (i = fila+2, j = columna+2; i < 7 && j < 7  && tab[i][j] == -turno; i++, j++);
			if (tab[i][j] == turno) {
				direccion[LOWERRIGHT] = true;
			}
		  }
		  
		  if (fila > 1 && columna < 6 && tab[fila-1][columna+1] == -turno) {
			for (i = fila-2, j = columna+2; i > 0 && j < 7  && tab[i][j] == -turno; i--, j++);
			if (tab[i][j] == turno) {
				direccion[UPPERRIGHT] = true;
			}
		  } 
		  //si en alguna direccion fue posible jugar retorna que la jugada
		  //es v?lida
		  for (i = 0; i < 8; i++){
			if (direccion[i] == true){
				return true;
			}
		  }
		  //si llega a este punto es porque la jugada no es v?lida en ninguna
		  //direcci?n
		return false;
	}
}

	/**
	 * Realiza una jugada del jugador con el turno en la posicion 
	 * correspondiente.
	 * @param x fila
	 * @param y columna
	 * @return resultado de la jugada 
	 */
	synchronized public int jugar(int x,int y){
		//@todo verificar rangos x y+
		//verificar si envian jugada x=-1 y=-1
		//significa que pasan 
		
		//si los dos jugadores pasan consecutivamente el juego se acaba
		ultJugada = new Jugada(x,y);
		if(x==-1 && y==-1){
			if(paso){
				if(cantrojas>cantazules)return GANA_JUGADOR_1;			
				else
					if(cantrojas<cantazules)return GANA_JUGADOR_2;
					else return EMPATE;
			}
			paso=true;
			turno=-turno;
			return OK;	
		}
		
		
		if (validarjugada(x,y)==false) return JUGADA_INVALIDA;
		paso=false;
		tab[x][y]=turno;
		turno = -turno; //se cambia el turno
		int i,j;

		//revisa en cuales direcciones debe voltear las fichas
		
		if (direccion[LEFT] == true){
		  for (i = y-1; tab[x][i] != -turno; i--){
			tab[x][i] = - tab[x][i];
		  }
		}
		
		if (direccion[RIGHT] == true){
		  for (i = y + 1; tab[x][i] != -turno; i++){
			tab[x][i] = - tab[x][i];
		  }
		}
		
		if (direccion[UPPER] == true){
		  for (j = x - 1; tab[j][y] != -turno; j--){
			tab[j][y] = - tab[j][y];
		  }
		}
		
		if (direccion[LOWER] == true){
		  for (j = x + 1; tab[j][y] != -turno; j++){
			tab[j][y] = - tab[j][y];
		  }
		}
		
		if (direccion[UPPERLEFT] == true){
		  for (i = y-1, j = x-1; tab[j][i] != -turno; i--, j--){
			tab[j][i] = - tab[j][i];
		  }
		}
		
		if (direccion[UPPERRIGHT] == true){
		  for (i = y+1, j = x-1; tab[j][i] != -turno; i++, j--){
			tab[j][i] = - tab[j][i];
		  }
		}
		
		if (direccion[LOWERRIGHT] == true){
		  for (i = y+1, j = x+1; tab[j][i] != -turno; i++, j++){
			tab[j][i] = - tab[j][i];
		  }
		}
		
		if (direccion[LOWERLEFT] == true){
		  for (i = y-1, j = x+1; tab[j][i] != -turno; i--, j++){
			tab[j][i] = - tab[j][i];
		  }
		}
		
		cuentapuntos(); //cuenta los puntos que se llevan
		//determina si el juego termin?
		if(cantrojas+cantazules==64){
		 if(cantrojas>cantazules) return GANA_JUGADOR_1;
		 else
		 	if(cantrojas<cantazules) return GANA_JUGADOR_2;
		 		else return EMPATE;
		}
		return OK;
	
	}
	/**
	 * Cuenta los puntos luego de cada jugada que es v?lida
	 */
	synchronized public void cuentapuntos(){
		int rojas=0;
		int azules=0;
		for (int i=0;i<8;i++){
			for(int j=0;j<8;j++){
				switch (tab[i][j]){
					case ROJO:
						rojas++;
						break;
					case AZUL:
						azules++;
						break;
				}
			}
		}
		cantrojas=rojas;
		cantazules=azules;
		cantvacios=64-rojas-azules;
	}

	/**
	 * Genera una representacion en ASCII del tablero
	 */
	synchronized public String toString(){
		StringBuffer result = new StringBuffer();
		result.append(ultJugada+"\n");
		for(int i=0;i<8;i++){
			for (int j=0;j<8;j++){
				result.append(tab[i][j]);
			}
			result.append("\n");
		}
		return result.toString();
	}

	/**
	 * @return Retorna la cantdiad de fichas azules.
	 */
	public synchronized int getCantazules() {
		return cantazules;
	}
	/**
	 * @return Retorna la cantdiad de fichas rojas.
	 */
	public synchronized int getCantrojas() {
		return cantrojas;
	}
	
	/**
	 * Permite probar la clase
	 * @param args no usado
	 */
	public static void main(String[] args)throws Exception {
		int x;
		int y;
		String valor;
		TableroModel model = new TableroModel(1);
		do{
			valor=JOptionPane.showInputDialog(null,"Introduzca la fila");
			x=Integer.parseInt(valor);
			valor=JOptionPane.showInputDialog(null,"Introduzca la columna");
			y=Integer.parseInt(valor);
			if(model.jugar(x,y)==JUGADA_INVALIDA) JOptionPane.showMessageDialog(null,"JUGADA INVALIDA");
			JOptionPane.showMessageDialog(null,"TABLERO\n"+model.toString());	
		}while(true);
		
	}

}
