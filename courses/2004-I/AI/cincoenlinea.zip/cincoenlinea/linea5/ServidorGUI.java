/*
 * Project: 5inline
 * File:    Servidor.java
 * Created on Mar 28, 2004
 *
 * Copyright 2004 Fabio Gonzalez, Daniel Penagos
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */
package linea5;

import java.awt.*;
import java.awt.event.ActionEvent;

import javax.swing.*;

/**
 * Implementacion del servidor del juego 5 en linea. Recibe conexiones 
 *  desde clientes posiblemente en una ubicacion remota. 
 * (@see linea5.Client ).
 *  Muestra el tablero graficamente y permite realizar una partida entre 2
 * clientes que se hayan conectado previamente.   
 *  @author Fabio Gonzalez, Daniel Penagos
 *  @date Mar 28, 2004 
 *   
 */
public class ServidorGUI extends JFrame implements ConnListener{
	String jug1;
	String jug2;
	ServidorModel modelo;
	TableroView view;
	ServidorComm communicat;
	int numjugadas=0;
	//componentes graficos
  BorderLayout borderLayout1 = new BorderLayout();
  JSplitPane jSplitPane1 = new JSplitPane();
  JScrollPane jScrollPane1 = new JScrollPane();
  JTextArea jTAMensajes = new JTextArea();
  JPanel jPanel2 = new JPanel();
  Box box3;
  BorderLayout borderLayout2 = new BorderLayout();
  JLabel jLabel2 = new JLabel();
  JComboBox jCBJugador1 = new JComboBox();
  JButton jBJugar = new JButton();
  JButton jBJugarCont = new JButton();
  JLabel jLabel1 = new JLabel();
  JComboBox jCBJugador2 = new JComboBox();
  JButton jBComenzar = new JButton();
  
  public ServidorGUI(){
  	communicat = new ServidorComm();
  	communicat.addConnListener(this);
		modelo = new ServidorModel(communicat,this);
		try {
			communicat.arrancarServidor();
		  jbInit();
		  setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		  setTitle("Cinco en Linea");
		}
		catch(Exception e) {
		  e.printStackTrace();
		}
  }
  
  private void jbInit() throws Exception {
		view = new TableroView(modelo.getTab());
		box3 = Box.createVerticalBox();
		jTAMensajes.setText("");
		jPanel2.setLayout(borderLayout2);
		jLabel2.setText("Jugador 2");
		jBJugar.setText("Jugar...");
		jBJugar.setEnabled(false);
		jBJugarCont.setText("Jugar Cont...");
		jBJugarCont.setEnabled(false);
		jBJugar.addActionListener(new Servidor_jBJugar_actionAdapter(this));
		jBJugarCont.addActionListener(new Servidor_jBJugarCont_actionAdapter(this));
		jLabel1.setText("Jugador 1");
		jBComenzar.setText("Comenzar");
		jBComenzar.addActionListener(new Servidor_jBComenzar_actionAdapter(this));
		jSplitPane1.add(jScrollPane1, JSplitPane.BOTTOM);
		jSplitPane1.add(jPanel2, JSplitPane.TOP);
		jPanel2.add(box3, BorderLayout.EAST);
		jPanel2.add(view, BorderLayout.CENTER);
		jScrollPane1.getViewport().add(jTAMensajes, null);
		box3.add(jLabel1, null);
		box3.add(jCBJugador1, null);
		box3.add(jLabel2, null);
		box3.add(jCBJugador2, null);
		box3.add(jBComenzar, null);
		box3.add(jBJugar, null);
		box3.add(jBJugarCont, null);
		
		this.getContentPane().setLayout(borderLayout1);
		this.getContentPane().add(jSplitPane1, BorderLayout.CENTER);
		jSplitPane1.setOrientation(JSplitPane.VERTICAL_SPLIT);
		jSplitPane1.setDividerLocation(259);
  }

  void jBComenzar_actionPerformed(ActionEvent e) {
		jug1 = (String) jCBJugador1.getSelectedItem();
		jug2 = (String) jCBJugador2.getSelectedItem();
		adicionaMensaje("Comenzando juego: "+jug1+" vs "+jug2+"\n");
		modelo.comenzarJuego(jug1,jug2);
		numjugadas=0;
		jBJugar.setEnabled(true);
		jBJugarCont.setEnabled(true);
		view.repaint();
	}

  void jBJugar_actionPerformed(ActionEvent e) {
  	numjugadas++;
  	long timeIni = System.currentTimeMillis();
		int result = modelo.jugar();
		long timeFin = System.currentTimeMillis();
		switch (result){
			case TableroModel.JUGADA_INVALIDA: 
				adicionaMensaje("Jugada Invalida!!\n");
				break;
			case TableroModel.GANA_JUGADOR_1:
				adicionaMensaje("Gana jugador 1: "+jug1+"\n");
				jBJugar.setEnabled(false);
				break;
			case TableroModel.GANA_JUGADOR_2:
				adicionaMensaje("Gana jugador 2: "+jug2+"\n");
				jBJugar.setEnabled(false);
				break;
			case TableroModel.OK:
				adicionaMensaje((modelo.getTab().getTurno()==2?jug1:jug2)+
					": "+(timeFin-timeIni)+" msec\n");
				if (numjugadas==64){
					adicionaMensaje("Empate\n");					
					jBJugar.setEnabled(false);
			}
				break;			
		}
		view.repaint();
	}

	void jBJugarCont_actionPerformed(ActionEvent e) {
		boolean flag=true;
		while (flag) {
			numjugadas++;
			long timeIni = System.currentTimeMillis();
			int result = modelo.jugar();
			long timeFin = System.currentTimeMillis();
			switch (result) {
				case TableroModel.JUGADA_INVALIDA :
					adicionaMensaje("Jugada Invalida!!\n");
					flag=false;
					break;
				case TableroModel.GANA_JUGADOR_1 :
					adicionaMensaje("Gana jugador 1: " + jug1 + "\n");
					flag=false;
					jBJugar.setEnabled(false);
					jBJugarCont.setEnabled(false);
					break;
				case TableroModel.GANA_JUGADOR_2 :
					adicionaMensaje("Gana jugador 2: " + jug2 + "\n");
					flag=false;
					jBJugar.setEnabled(false);
					jBJugarCont.setEnabled(false);
					break;
				case TableroModel.OK :
					adicionaMensaje(
						(modelo.getTab().getTurno() == 2 ? jug1 : jug2)
							+ ": "
							+ (timeFin - timeIni)
							+ " msec\n");
					if (numjugadas == 64) {
						adicionaMensaje("Empate\n");
						flag=false;
						jBJugar.setEnabled(false);
						jBJugarCont.setEnabled(false);
					}
					break;
			}
			view.repaint();
		}
	  }

	public void adicionaMensaje(String m){
		jTAMensajes.append(m);
		JScrollBar sb =	jScrollPane1.getVerticalScrollBar();
		sb.setValue(sb.getMaximum());
	}
	
	private void addCliente(String name){
		jTAMensajes.append("****************\nNuevo cliente:"+name+"\n****************\n");
		jCBJugador1.addItem(name);
		jCBJugador2.addItem(name);
	}
	
	
	
  public static void main(String[] args) throws HeadlessException {
		ServidorGUI serv = new ServidorGUI();
		serv.setSize(400,512);
		serv.setVisible(true);
  }
	
	/* (non-Javadoc)
	 * @see linea5.ConnListener#nuevaConexion(java.lang.String)
	 */
	public void nuevaConexion(String name) {
		addCliente(name);
	}
	
	/* (non-Javadoc)
	 * @see linea5.ConnListener#removerConexion(java.lang.String)
	 */
	public void removerConexion(String name) {
		
	}

}

class Servidor_jBComenzar_actionAdapter implements java.awt.event.ActionListener {
  ServidorGUI adaptee;

  Servidor_jBComenzar_actionAdapter(ServidorGUI adaptee) {
		this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
		adaptee.jBComenzar_actionPerformed(e);
  }
}

class Servidor_jBJugar_actionAdapter implements java.awt.event.ActionListener {
  ServidorGUI adaptee;

  Servidor_jBJugar_actionAdapter(ServidorGUI adaptee) {
		this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
		adaptee.jBJugar_actionPerformed(e);
  }
}

class Servidor_jBJugarCont_actionAdapter implements java.awt.event.ActionListener {
  ServidorGUI adaptee;

  Servidor_jBJugarCont_actionAdapter(ServidorGUI adaptee) {
		this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
		adaptee.jBJugarCont_actionPerformed(e);
  }
}

