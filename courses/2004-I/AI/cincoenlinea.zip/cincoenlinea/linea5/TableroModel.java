/*
 * Project: 5inline
 * File:    TableroModel.java
 * Created on Mar 27, 2004
 *
 * Copyright 2004 Fabio Gonzalez, Daniel Penagos
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */
package linea5;

import java.io.Serializable;



/**
 * Representacion logica del tablero
 *  @author Fabio Gonzalez
 *  @date Mar 27, 2004 
 */
public class TableroModel implements Serializable{
	/**
	 * La jugada se ejecuto correctamente (no hubo un ganador)
	 */
	public static final int OK = 0;
	/**
	 * Se jugo en una posicion invalida.
	 */
	public static final int JUGADA_INVALIDA = -1;
	/**
	 * Gano el jugador 1.
	 */
	public static final int GANA_JUGADOR_1 = 1;
	/**
	 * Gano el jugador 2.
	 */
	public static final int GANA_JUGADOR_2 = 2;
	
	/**
	 * Representacion del tablero como una matriz.
	 */
	protected int[][] tab;
	/**
	 * Numero del jugador que le corresponde jugar en la siguiente jugada.
	 */
	protected int turno;
	
	
	/**
	 * Copy constructor. Crea una nueva instancia de la clase con los mismos
	 * datos de la instancia parametro.
	 * @param otrotab instancia a ser copiada.
	 */
	public TableroModel(TableroModel otrotab){
		turno=otrotab.turno;
		tab = new int[8][8];
		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++){
				tab[i][j]=otrotab.tab[i][j];
			}
		}
		
	}
	/**
	 * @param turno_inicial el jugador que va a jugar primero
	 */
	public TableroModel(int turno_inicial){
		if (turno_inicial!=1 && turno_inicial!=2){
			System.err.println("TableroModel: argumento erroneo:" + turno_inicial);
		}
		turno=turno_inicial;
		tab = new int[8][8];
	}
		
	/**
	 * Pone un valor en el tablero sin validar 
	 * @param x fila 
	 * @param y columna
	 * @param who valor a guardar (1 -> jugador 1, 2 -> jugador 2)
	 */
	protected void set(int x, int y, int who){
		tab[x][y]=who;
	}

	/**
	 * Limpia el tablero 
	 */
	synchronized public void clear() {
		for(int i=0;i<8;i++){
			for(int j=0;j<8;j++){
				tab[i][j]=0;
			}
		}
		turno=1;
	}

	/**
	 * Obtiene el valor almacenado en una posicion del tablero
	 * @param x fila 
	 * @param y columna
	 * @return valor almacenado (0 -> vacio, 1 -> jugador 1, 2 -> jugador 2)
	 */
	synchronized public int get(int x,int y){
		return tab[x][y];
	}

	/** 
	 * @return el numero de l jugador que le corresponde jugar en la
	 * siguiente jugada.
	 */
	synchronized public int getTurno() {
		return turno;
	}
	
	/**
	 * Ejecuta una jugada poniendo una ficha del jugador con el turno 
	 * (<code> turno </code>).
	 * @param jugada
	 */
	synchronized public int  jugar(Jugada jugada) {
		return jugar(jugada.x,jugada.y);		
	}

	/**
	 * Realiza una jugada del jugador con el turno en la posicion 
	 * correspondiente.
	 * @param x fila
	 * @param y columna
	 * @return resultado de la jugada 
	 */
	synchronized public int jugar(int x,int y){
		//@todo verificar rangos x y
		if (tab[x][y]!=0) return JUGADA_INVALIDA;
		tab[x][y]=turno;
		turno = 3-turno;
		//revisa horizontales
		for(int i=0;i<8;i++){
			for(int jini=0;jini<4;jini++){
				int sum=0;
				for(int j=jini;j<jini+5;j++){
					if (tab[i][j]>0)
						sum+=tab[i][j]==1?1:10;
				}
				if (sum==5) return GANA_JUGADOR_1;
				if (sum==50) return GANA_JUGADOR_2;
			}
		}
		//revisa verticales
		for(int j=0;j<8;j++){
			for(int iini=0;iini<4;iini++){
				int sum=0;
				for(int i=iini;i<iini+5;i++){
					if (tab[i][j]>0)
						sum+=tab[i][j]==1?1:10;
				}
				if (sum==5) return GANA_JUGADOR_1;
				if (sum==50) return GANA_JUGADOR_2;
			}
		}
		//revisa diagonales
		for(int iini=0;iini<4;iini++){
			for(int jini=0;jini<4;jini++){
				int sum=0;
				for (int i=iini,j=jini; i<iini+5;i++,j++){
					if (tab[i][j]>0)
						sum+=tab[i][j]==1?1:10;					
				}
				if (sum==5) return GANA_JUGADOR_1;
				if (sum==50) return GANA_JUGADOR_2;
			}
		}
		//revisa diagonales opuestas
		for(int iini=0;iini<4;iini++){
			for(int jini=4;jini<8;jini++){
				int sum=0;
				for (int i=iini,j=jini; i<iini+5;i++,j--){
					if (tab[i][j]>0)
						sum+=tab[i][j]==1?1:10;					
				}
				if (sum==5) return GANA_JUGADOR_1;
				if (sum==50) return GANA_JUGADOR_2;
			}
		}									
		return OK;
	}
	synchronized public String toString(){
		StringBuffer result = new StringBuffer();
		for(int i=0;i<8;i++){
			for (int j=0;j<8;j++){
				result.append(tab[i][j]);
			}
			result.append("\n");
		}
		return result.toString();
	}
	
	/**
	 * Permite probar la clase
	 * @param args no usado
	 */
	public static void main(String[] args)throws Exception {
		TableroModel model = new TableroModel(1);
		model.jugar(0,0);
		model.jugar(0,1);
		model.jugar(1,1);
		model.jugar(0,2);
		model.jugar(2,2);
		model.jugar(0,3);
		model.jugar(3,3);
		System.out.println(model.jugar(0,4));
		System.out.println(model.jugar(4,5));
		System.out.println(model.jugar(0,1));
		
	}


}
