/*
 * Project: 5inline
 * File:    TableroGUI.java
 * Created on Mar 27, 2004
 *
 * Copyright 2004 Fabio Gonzalez, Daniel Penagos
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */
package linea5;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

/**
 * Representacion grafica del tablero.
 *  @author Fabio Gonzalez, Daniel Penagos
 *  @date Mar 27, 2004 
 */
public class TableroView extends JPanel {

	TableroModel tabModel;
	Image imficharoja;
	Image imfichaazul;

	/**
	 * Construye una instancia que muestra graficamente el Modelo
	 * del Tablero enviado como argumento.
	 * @param tm TableroModel a pintar
	 */
	public TableroView(TableroModel tm){
		tabModel = tm;
		imficharoja = new ImageIcon(
			getClass().getResource("/imagenes/ficharoja.JPG")).getImage()
			.getScaledInstance(32,-1,Image.SCALE_SMOOTH);
		imfichaazul=new ImageIcon(
			getClass().getResource("/imagenes/fichaazul.JPG")).getImage()
			.getScaledInstance(32,-1,Image.SCALE_SMOOTH);
		setMinimumSize(new Dimension(256,256));
	}

	/**
	 * Asigna el TableroModel que sera visualizado
	 * @param tm modelo
	 */
	public void setModel(TableroModel tm){
		tabModel = tm;
		repaint();
	}
	
	/* (non-Javadoc)
	 * @see java.awt.Component#paint(java.awt.Graphics)
	 */
	public void paintComponent(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 257, 257);
		g.setColor(Color.BLACK);
		int coordcolumn = 0;
		int coordfila = 0;
		int i = 0;

		for (int fila = 0; fila < 8; fila++) {
			for (int column = 0; column < 8; column++) {

				g.setColor(Color.black);
				g.drawRect(coordcolumn, coordfila, 32, 32);

				switch (tabModel.get(fila, column)) {
					case 0 :
						{
							break;
						}
					case 1 : //ficha roja
						{
							g.drawImage(
								imficharoja,
								coordcolumn,
								coordfila,
								this);
							break;
						}
					case 2 : //ficha azul
						{
							g.drawImage(
								imfichaazul,
								coordcolumn,
								coordfila,
								this);
							break;
						}
				}
				coordcolumn += 32;
			}
			coordcolumn = 0;
			coordfila += 32;
		}

	}

	/**
	 * Permite probar el componente
	 * @param args no se usa
	 */
	public static void main(String[] args)throws Exception {
		JFrame jf = new JFrame("Test TableroView");
		jf.getContentPane().setLayout(new BorderLayout());
		TableroModel tm = new TableroModel(1);
		tm.jugar(1,1);
		tm.jugar(2,2);
		jf.getContentPane().add(new TableroView(tm));
		jf.setSize(200,200);
		jf.setVisible(true);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

}
