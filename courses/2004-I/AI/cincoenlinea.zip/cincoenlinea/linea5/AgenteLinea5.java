/*
 * Project: 5inline
 * File:    AgenteLinea5.java
 * Created on Mar 31, 2004
 * 
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */
 
package linea5;

/**
 *  Esta clase sirve como base para escribir su propio codigo. Esta clase es 
 * la unica clase que, en principio, se debe modificar.
 *  @author Fabio Gonzalez
 *  @date Mar 31, 2004 
 */
public class AgenteLinea5 {
	
	/**
	 * Efectua la jugada del agente basada en el estado actual del tablero. <br> 
	 * Tenga en cuenta que el tablero tiene la informacion sobre la ficha 
	 * que esta jugando actualmente. <b>Aqui debe ir su codigo</b>. 
	 * @param tab objeto representando el estado actual del tablero
	 * @return La jugada a efectuar.
	 */
	public Jugada calculaJugada(TableroModel tab){
//		for(int i=0;i<8;i++){
//			for(int j=0;j<8;j++){
//				if (tab.get(i,j)==0){
//					return new Jugada(i,j);
//				}
//			}			
//		}
		while(true){
			int i =(int)(Math.random()*7.9);
			int j =(int)(Math.random()*7.9);
			if (tab.get(i,j)==0){
				return new Jugada(i,j);
			}
		}
	}
}
