/*
 * Project: 5inline
 * File:    ServidorModel.java
 * Created on Mar 29, 2004
 * 
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * 
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */
 
package linea5;

/**
 * Maneja la parte logica del servidor (@see linea5.ServidorGUI)
 *  @author Fabio Gonzalez
 *  @date Mar 29, 2004 
 */
public class ServidorModel{
	ServidorComm comm;
	ServidorGUI gui;
	TableroModel tab;
	String jug1,jug2;
	

	public ServidorModel(ServidorComm sc,ServidorGUI sg){
		comm=sc;
		gui=sg;
		tab=new TableroModel(1);		
	}
	
	public void comenzarJuego(String j1, String j2){
		jug1 = j1;
		jug2 = j2;
		tab.clear();
	}
	
	public int jugar(){
		String jugador;
		if(tab.getTurno()==1){
			jugador=jug1;
		}else{
			jugador=jug2;
		}
		Jugada jugada = comm.obtenerJugadaSiguiente(jugador,tab);
		int result = tab.jugar(jugada);
		return result;
	}
	
	/**
	 * @return
	 */
	public TableroModel getTab() {
		return tab;
	}

}
