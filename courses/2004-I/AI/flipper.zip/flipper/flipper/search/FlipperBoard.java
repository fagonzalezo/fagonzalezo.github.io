package flipper.search;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UN</p>
 * @author Fabio Gonzalez
 * @version 1.0
 */

public class FlipperBoard {
	int x=-1,y=-1;
  boolean[][] board;
  public FlipperBoard() {
    board = new boolean[][]{{false,false,false},{false,false,false},
        {false,false,false}};
  }

  public FlipperBoard(boolean[][] b){
    board = b;
  }

  private void flip(int i,int j){
    board[i][j] = !board[i][j];
  }

  public void hit(int i,int j){
  	x=i;y=j;
    flip(i,j);
    if (i == 1) {
      flip(0, j);
      flip(2, j);
    }
    if (j == 1) {
      flip(i, 0);
      flip(i, 2);
    }
    if (i != 1 && j != 1) {
      flip(i, 1);
      flip(1, j);
    }
  }
  
  public void setBoard(FlipperBoard aBoard){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
  			board[i][j]=aBoard.board[i][j];
			}
		}
  }
  
  public boolean equals(Object o){
  	boolean retval = true;
  	FlipperBoard fb = (FlipperBoard) o;
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if (board[i][j] != fb.board[i][j]){
					retval = false;
					break;
				}
			}
		}
		return retval;	
	}
	
	public String getLastAction(){
		return "("+x+","+y+")";
	}
	
	public String toString(){
		String result = "---("+x+","+y+")\n";
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				result+=board[i][j]?'X':'*';
			}
			result+='\n';
		}
		result+="---";
		return result;
	}
}
