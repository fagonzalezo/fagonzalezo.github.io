/*
 * Created on Mar 11, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package flipper.search;

import java.util.ArrayList;

import aima.search.DepthFirstSearchFunction;
import aima.search.Node;
import aima.search.Problem;
import aima.search.SearchAgent;
import aima.search.SearchFunction;

/**
 * 
 *  @author Fabio Gonzalez
 *  @date Mar 11, 2004 
 */
public class FlipperSearchAgent extends SearchAgent {

	
	/**
	 * 
	 */
	public FlipperSearchAgent(boolean [][] configuration){
		setProblem(new FlipperProblem(configuration));
	 	setSearchFunction(new DepthFirstSearchFunction(10));
		setUp();
	}

	public FlipperSearchAgent(int depthOfSearch,Problem p,SearchFunction f){
		setProblem(p);
		setSearchFunction(f);
		setUp();
	}
	

	/* (non-Javadoc)
	 * @see aima.search.SearchAgent#nodesToActions(java.util.ArrayList)
	 */
	public ArrayList nodesToActions(ArrayList nodes) {
		ArrayList retVal= new ArrayList();
		if (nodes.size() > 0){
//			nodes.remove(0); //remove initial state node
			for (int i=0;i<nodes.size();i++){
				Node n = (Node)nodes.get(i);
			   FlipperBoard board = (FlipperBoard)n.getState();
				 retVal.add(board.toString());
			}
		}
		return retVal;
	}

}
