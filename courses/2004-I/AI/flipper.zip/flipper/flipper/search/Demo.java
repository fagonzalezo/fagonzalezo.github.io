/*
 * Created on Mar 11, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package flipper.search;

import aima.search.BreadthFirstSearchFunction;
import aima.search.DepthFirstSearchFunction;
import aima.search.InstrumentedProblem;
import aima.search.IterativeDepthFirstSearchFunction;

/**
 * 
 *  @author Fabio Gonzalez
 *  @date Mar 11, 2004 
 */
public class Demo {

	public static void main(String[] args) {
		FlipperProblem p = new FlipperProblem(new boolean[][]
			{{true,false,false},{true,true,false},{false,false,false}});
		InstrumentedProblem ip  = new InstrumentedProblem(p);
		FlipperSearchAgent a = new FlipperSearchAgent(15,ip,new IterativeDepthFirstSearchFunction(15));
		//FlipperSearchAgent a = new FlipperSearchAgent(25,ip,new BreadthFirstSearchFunction(25));
		a.printActions();
		ip.printStats();
	}
}

