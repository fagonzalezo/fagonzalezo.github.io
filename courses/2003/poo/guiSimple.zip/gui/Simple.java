/*
 * Created on Nov 5, 2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package gui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

/**
 *  
 *  @author Fabio Gonzalez
 *  @date Nov 5, 2003 
 */
public class Simple extends JFrame implements ActionListener {

	private JButton boton =  new JButton("Presione..."); 
	private JLabel etiqueta = new JLabel("Esperando....");

	public Simple(){
		//Sale de la aplicacion cuando se cierra la ventana
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		//Pone el titulo de la ventana
		setTitle("Ventana principal");
		//Pone layout
		getContentPane().setLayout(new FlowLayout());
		//adiciona componentes
		getContentPane().add(boton);
		getContentPane().add(etiqueta);
		//define tamano
		setSize(300,100);
		//adiciona listener para el boton
		boton.addActionListener(this);
		//muestra la ventana
		setVisible(true);
	}
	public void actionPerformed(ActionEvent arg0) {
		etiqueta.setText("Presionado!!");
	}

	public static void main(String[] args) {
		new Simple();
	}
}
