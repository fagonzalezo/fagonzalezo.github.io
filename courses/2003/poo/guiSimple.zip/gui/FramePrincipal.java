package gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/*
 * FramePrincipal.java
 *
 * Created on 2 de noviembre de 2003, 04:55 PM
 */

/**
 * Clase principal que hereda de JFrame
 */
public class FramePrincipal extends javax.swing.JFrame {
    
    /** Crea nueva ventana FramePrincipal */
    public FramePrincipal() {
      initComponents();
			this.setSize(500, 200 );
			this.setVisible( true );
    }
    
    private void initComponents() {
				//Sale de la aplicacion cuando se cierra la ventana
				setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
				//Pone el titulo de la ventana
				setTitle("Ventana principal");
				//No permite cambiar el tamano de la ventana.
				//setResizable(false);


    		// Layout para el content pane del frame
    		getContentPane().setLayout(new BorderLayout());
    		
				// Crea una etiqueta y la pone al norte
        PrincipalLabel = new JLabel();
				PrincipalLabel.setHorizontalAlignment(SwingConstants.CENTER);
				PrincipalLabel.setText("Este es un JLabel en la parte norte del BorderLayout");
				getContentPane().add(PrincipalLabel, java.awt.BorderLayout.NORTH);

				// Crea un panel y le asigna GridLayout con 2 filas, 1 columna 
				// y 30 puntos de espacio vertical entre los componentes.
				// Adiciona este panel al occidente
				panelOccidental = new JPanel();
				panelOccidental.setLayout(new java.awt.GridLayout(2, 1, 0, 30));
				getContentPane().add(panelOccidental, java.awt.BorderLayout.WEST);

				//Este panel va dentro del panelOccidental
				panelOccidental1 = new JPanel();
				panelOccidental.add(panelOccidental1);
				
				// Una etiqueta dentro de panelOccidental1
				entradaLabel = new JLabel();
				entradaLabel.setText("ingrese texto y presione enter");
				entradaLabel.setToolTipText("null");
				panelOccidental1.add(entradaLabel);

				// Un campo de texto dentro de panelOccidental1						
				entradaTextField = new JTextField();
				entradaTextField.setPreferredSize(new java.awt.Dimension(50, 20));
				entradaTextField.setToolTipText("Ingrese texto");
				panelOccidental1.add(entradaTextField);

				//Este panel va dentro de panelOccidental
				panelOccidental2 = new JPanel();
				panelOccidental.add(panelOccidental2);
		
				// 2 checkboxes para panel Occidental2
				primerCheckBox = new JCheckBox();
				segundoCheckBox = new JCheckBox();
				primerCheckBox.setSelected(true);
				primerCheckBox.setText("Primer check box");
				panelOccidental2.add(primerCheckBox);
				segundoCheckBox.setText("Segundo check box");
				panelOccidental2.add(segundoCheckBox);
		
				// Un panel con 2 botones se adiciona al sur
        panelSur = new JPanel();
				panelSur.setLayout(new java.awt.GridLayout(1, 2, 10, 10));
				getContentPane().add(panelSur, java.awt.BorderLayout.SOUTH);
        primerBoton = new JButton();
        segundoBoton = new JButton();
				primerBoton.setText("Primer Boton");
				panelSur.add(primerBoton);
				segundoBoton.setText("Boton de limpiar");
				panelSur.add(segundoBoton);
				
				//Se adiciona un area de texto en el centro
				resultadosTextArea = new JTextArea();
				getContentPane().add(resultadosTextArea, java.awt.BorderLayout.CENTER);

				// Se adiciona comportamiento a los componentes usando Listeners

        //Listener del boton 1
        primerBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                primerBotonActionPerformed(evt);
            }
        });
        //Listener del boton 2
        segundoBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                segundoBotonActionPerformed(evt);
            }
        });

				// Listener del campo de texto
        entradaTextField.addActionListener( new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						resultadosTextArea.append( "Ingreso:\n " + 
						entradaTextField.getText() + "\nEn entradaTextFiedl\n");
						
					}
        });
        
        //Listener del checkbox 1
        primerCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                primerCheckBoxActionPerformed(evt);
            }
        });

				//Listener del checkbox 2
				segundoCheckBox.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						segundoCheckBoxActionPerformed(evt);
					}
				});
    }

    private void primerCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {
    	if ( this.primerCheckBox.isSelected() ) {
			this.resultadosTextArea.append( "Selecciono el primerCheckBox\n" );
    	}else{
			this.resultadosTextArea.append( "Deselecciono el primer CheckBox\n" );
    	}
    }

		private void segundoCheckBoxActionPerformed(ActionEvent evt) {
			if ( this.segundoCheckBox.isSelected() ) {
				this.resultadosTextArea.append( "Selecciono el segundo CheckBox\n" );
			}else{
				this.resultadosTextArea.append( "Deselecciono el segundo CheckBox\n" );
			}
		}
	
    private void segundoBotonActionPerformed(java.awt.event.ActionEvent evt) {
        this.resultadosTextArea.setText( "" );
    }

    private void primerBotonActionPerformed(java.awt.event.ActionEvent evt) {
        this.resultadosTextArea.append( "Oprimio el primer boton \n" );
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        new FramePrincipal();
    }
    
    
    private JCheckBox segundoCheckBox;
    private JTextField entradaTextField;
    private JButton segundoBoton;
    private JPanel panelSur;
    private JPanel panelOccidental2;
    private JPanel panelOccidental1;
    private JTextArea resultadosTextArea;
    private JLabel entradaLabel;
    private JCheckBox primerCheckBox;
    private JButton primerBoton;
    private JPanel panelOccidental;
    private JLabel PrincipalLabel;
    
}
