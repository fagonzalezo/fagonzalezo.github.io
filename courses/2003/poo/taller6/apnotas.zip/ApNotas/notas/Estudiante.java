
package notas;

import java.util.Iterator;
import java.util.Vector;


/**
 * Esta clase representa un estudiante con su nombre, codigo y notas.
 * @author Fabio Gonzalez
 */
public class Estudiante {
	private String nombre;
	private int codigo;
	private Vector notas;
	
	/**
	 * Crea un nuevo estudiante con un nombre y codigo dados.
	 * @param nom nombre del estudiante
	 * @param cod codigo del estudiante
	 */
	public Estudiante(String nom, int cod){
		nombre=nom;
		codigo=cod;
		notas=new Vector();
	}
	
	/**
	 * Agrega una nota al estudiante. El estudiante puede tener tantas notas
	 * como se quiera.
	 * @param nota la nota a agregar
	 */
	public void  agregaNota(double nota){
		notas.add(new Double(nota));
	}

	/**
	 * Calcula el promedio de las notas del estudiante (suma de las notas 
	 * dividido por el numero de notas)
	 * @return el promedio de las notas
	 */
	public double promedio(){
		double suma=0;
		Iterator iter = notas.iterator();
		while (iter.hasNext()) {
			Double element = (Double) iter.next();
			suma += element.doubleValue();
		}
		return suma/notas.size();
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return codigo+" "+nombre+" "+promedio();
	}
}
