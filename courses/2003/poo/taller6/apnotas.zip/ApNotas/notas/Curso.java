
package notas;

import java.io.*;
import java.util.*;


/**
 * Esta clase representa un conjunto de estudiantes
 * @author Fabio Gonzalez
 */
public class Curso {
	private Vector estuds;
	
	/**
	 * Crea un conjunto de estudiantes vacio
	 */
	public Curso(){
		estuds = new Vector();
	}
	
	/**
	 * Agrega un estudiante al conjunto de estudiantes
	 * @param estud  el estudiante a ser agregado
	 */
	public void agregaEstud(Estudiante estud){
		estuds.add(estud);
	}
	
	
	/**
	 * Lee una lista de estudiantes con sus notas desde un archivo
	 * y los agrega al conjunto de estudiantes 
	 * @param archivo nombre del archivo donde se encuentra la lista de estudiantes
	 */
	public void leeArchivo(String archivo){
		File file = new File(archivo);
		try{
			BufferedReader in = new BufferedReader(new FileReader(file));
			String line;
			while((line=in.readLine())!=null){
				String[] tokens = line.split(",");
				Estudiante estud = new Estudiante(tokens[1],
					Integer.parseInt(tokens[0]));
				for(int i=2;i<tokens.length;i++){
					estud.agregaNota(Double.parseDouble(tokens[i]));
				}
				estuds.add(estud);
			}
			in.close();
		}catch(FileNotFoundException exc){
			System.out.println("No se encontro el archivo:"+archivo);
		}catch (IOException exc) {
			System.out.println("Error leyendo el archivo");
			exc.printStackTrace();
		}catch (NumberFormatException exc) {
			System.out.println("Error en el formato numerico");
			exc.printStackTrace();
		}
	}

	/**
	 * Genera una lista de los estudiantes con sus respectivas notas finales
	 * @param out flujo de salida donde se imprimira la lista de estudiantes.
	 * Puede ser un archivo o la consola.
	 */
	public void imprimeNotas(PrintWriter out){
		Iterator iter = estuds.iterator();
		while (iter.hasNext()) {
			Estudiante estud =  (Estudiante)iter.next();
			out.println(estud.toString());
		}
	}
}
