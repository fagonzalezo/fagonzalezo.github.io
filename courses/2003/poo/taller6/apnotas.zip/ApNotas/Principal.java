import java.io.*;

import notas.Curso;



/**
 * Esta clase permite probar el paquete de notas. Recibe un argumento en
 * linea de comandos que representa el nombre de un archivo que contiene
 * una lista de estudiantes (Un estudiante por linea) con el siguiente 
 * formato: <br> <br>
 * <code> codigo,nombre,nota_1,nota_2,nota_3,...,nota_n </code> <br> <br>
 * El programa imprime por consola la lista de estudiantes con su 
 * respectivo promedio.
 *  @author Fabio Gonzalez
 *  @date Oct 18, 2003 
 */
public class Principal {

	public static void main(String[] args) {
		Curso curso = new Curso();
		if (args.length == 0){
			System.out.println(
				"El programa se debe invocar con al menos un parametro");
			return;
		}
		curso.leeArchivo(args[0]);
		if(args.length == 1){
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(System.out));
			curso.imprimeNotas(pw);
			pw.close();
		}else{
			System.out.println("Error: debe especificar el archivo de entrada!!");
		}
	}
}
