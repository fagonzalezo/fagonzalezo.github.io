/*
 * Project: Hex
 * File:    ServidorComm.java
 * Created on Mar 29, 2004
 *
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y
 * cuando se mantenga el anterior aviso de Copyright.
 *
 * This code could be used, modified and redistributed, provided that the above
 * copyright notice is retained.
 */
package hex_game;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/**Maneja las comunicaciones para el servidor. Mantiene una lista de todas
 * las conexiones activas. Provee una interfaz que hace la comunicacion
 * transparente.
 *  @author Fabio Gonzalez*/
public class ServidorComm implements Runnable{
    /**Socket asignado a una nueva conexion*/
    private Socket socket;
    /**HashMap que mantiene una lista de las conexiones activas en el servidor*/
    private HashMap conexiones = new HashMap();
    
    private HashSet listeners = new HashSet();
    /**Puerto en el cual escucha el servidor*/
    public static final int PORT=9000;
    
    /**Metodo que arranca el servidor para escuchar peticiones*/
    public void arrancarServidor() throws IOException {
        new Thread(this).start();
    }
    
    /**Esta esperando por una conexi�n de un nuevo cliente, si llega una conexi�n 
     * Agrega el nuevo cliente a*/
    private void escuchar() throws IOException{
        ServerSocket s = new ServerSocket(PORT);        
        System.out.println("Server Started");
        try {
            while (true) {
                // Blocks until a connection occurs:
                Socket socket = s.accept();
                try {
                    ServeOne conexion = new ServeOne(socket);
                    String nombre = conexion.getNombre();
                    conexiones.put(nombre,conexion);
                    Iterator iter = listeners.iterator();
                    
                    while (iter.hasNext()) {
                        ConnListener element = (ConnListener) iter.next();
                        element.nuevaConexion(nombre);
                    }
                } catch (IOException e) {
                    // If it fails, close the socket,
                    // otherwise the thread will close it:
                    socket.close();
                }
            }
        } finally {
            s.close();
        }
    }
    
        /* (non-Javadoc)
         * @see java.lang.Runnable#run()
         */
    public void run() {
        try {
            escuchar();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
   
    public void addConnListener(ConnListener listener){
        listeners.add(listener);
    }
    public void removeConnListener(ConnListener listener){
        listeners.remove(listener);
    }
    /**Retorna la siguiente jugada del jugador
     @param nomJugador Nombre del jugador
     @param tablero Tablero Actual del juego
     @return La jugada enviada por el jugador*/
    public Jugada obtenerJugadaSiguiente(String nomJugador,TableroModel tablero){
        ServeOne conexion = (ServeOne) conexiones.get(nomJugador);
        return conexion.jugar(tablero);
    }
    /**Funcion que verifica si un jugador conectado al servidor es v�lido
     *@param nomJugador Nombre del jugador a verificar
     @return booleano que indica si el jugador es v�lido o no*/
    public boolean isJugadorValido(String nomJugador){
        ServeOne conexion = (ServeOne) conexiones.get(nomJugador);
        if(conexion!=null){
            if(!conexion.isClosed())
                return true;
            else
                conexiones.remove(nomJugador);
        }
        return false;
    }
    public static void main(String[] args) {
        try {
            ServidorComm servidor = new ServidorComm();
            servidor.arrancarServidor();
            servidor.addConnListener(new TestServidorComm());
            BufferedReader in = new BufferedReader(
            new InputStreamReader(System.in));
            in.readLine();
            //			servidor.obtenerJugadaSiguiente("hola");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
/**Clase que maneja individualmente cada conexion y socket de un cliente*/
class ServeOne{
    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;
    private String nombre;
    
    /**Constructor asigna el nuevo socket y le envia al cliente la petici�n del nombre o nick
     *@ s Socket asignado al cliente*/
    public ServeOne(Socket s)
    throws IOException {
        socket = s;
        out = new ObjectOutputStream(
        socket.getOutputStream());
        out.flush();
        in = new ObjectInputStream(
        socket.getInputStream());
        obtieneNombre();
    }
    
    /**Obtiene el nombre del cliente conectado pide el nombre del cliente via sockets*/
    private void obtieneNombre() throws IOException {
        String str = null;
        try {
            str = (String) in.readObject();
        } catch (ClassNotFoundException e) {
            System.err.println("ServerOne: Objeto leido no es instancia de String");
            e.printStackTrace();
        }
        nombre = str;
    }
    /**Retorna el nombre del cliente*/
    public String getNombre(){
        return nombre;
    }
    /**Envia al cliente la petici�n de una jugada con el tablero correspondiente
     * y espera un objeto de tipo Jugada para retornarlo cierra el socket si se 
     * produce algun error
     @param tablero Tablero actual del juego*/
    
    public Jugada jugar(TableroModel tablero){
        
        try {
            //System.out.println(tablero.toString());
            out.writeObject(new TableroModel(tablero));
            out.flush();
            Jugada jug = (Jugada) in.readObject();
            //System.out.println("Jugada:" + jug);
            return jug;
        } catch (IOException e) {
            System.err.println("ServeOne:error comunicandose con el cliente");
            try{
                socket.close();
            }catch(IOException ei){
                System.err.println("ServeOne:error cerrando el socket");
                ei.printStackTrace();
            }
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            try{
                socket.close();
            }catch(IOException ei){
                System.err.println("ServeOne:error cerrando el socket");
                ei.printStackTrace();
            }
            
            System.err.println("ServeOne:error con el objeto recibido");
            e.printStackTrace();
        }
        return null;
    }
    /**Metodo que averigua si el socket es v�lido o no
     @return Booleano que indica si el socket esta abierto*/
    public boolean isClosed(){
        return socket.isClosed();
    }
}

/**Clase que implementa ConnListener*/
class TestServidorComm implements ConnListener{
    
        /* (non-Javadoc)
         * @see linea5.ConnListener#nuevaConexion(java.lang.String)
         */
    public void nuevaConexion(String name) {
        System.out.println("Nueva conexi�n desde:" + name + "\n");
    }
    
        /* (non-Javadoc)
         * @see linea5.ConnListener#removerConexion(java.lang.String)
         */
    public void removerConexion(String name) {
        
    }
    
}