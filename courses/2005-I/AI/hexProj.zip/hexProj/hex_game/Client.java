/*
 * Project: Hex
 * File: Client.java
 * Created on Mar 31, 2004
 *
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y
 * cuando se mantenga el anterior aviso de Copyright.
 * Modificado por Johann Camilo Olarte D�az
 * This code could be used, modified and redistributed, provided that the above
 * copyright notice is retained.
 */

package hex_game;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;



/**
 * Programa cliente. Se conecta al servidor usando sockets.
 * El programa debe ser invocado de la siguiente forma: <br>
 * <code>
 * 	java hexgame.Cliente <direccion servidor> <nombre cliente>
 * </code>
 * @author Fabio Gonzalez
 *
 */
public class Client {
    
    /**Corre el programa cliente. usando una instancia de AgenteHex para calcular la
     * jugada a enviar al servidor
     * @param args direccion ip servidor, Nombre o nick del cliente
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        Agentehex agente = new Agentehex();
        InetAddress addr = InetAddress.getByName(args[0]);
        System.out.println("addr = " + addr);
        Socket socket = new Socket(addr, ServidorComm.PORT);
        try {
            System.out.println("socket = " + socket);
            ObjectInputStream in = new ObjectInputStream(
            socket.getInputStream());
            ObjectOutputStream out = new ObjectOutputStream(
            socket.getOutputStream());
            out.writeObject(args[1]);
            out.flush();
            String str;
            TableroModel tab;
            do {
                tab = (TableroModel) in.readObject();
                System.out.println("Recibiendo:\n" + tab.toString());
                Jugada jugada = agente.calculaJugada(tab);
                System.out.println("enviando:" + jugada);
                out.writeObject(jugada);
                tab.clear();
                out.flush();
                System.gc(); 
            } while (true);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            System.out.println("closing...");
            socket.close();
        }
    }
}
