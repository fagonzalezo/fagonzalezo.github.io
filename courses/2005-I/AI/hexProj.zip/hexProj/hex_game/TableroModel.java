/**
 * Project: Hex
 * File:    TableroModel.java
 * Created on Feb 19, 2005
 *
 * Copyright 2005 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y
 * cuando se mantenga el anterior aviso de Copyright.
 * MODIFICADO POR JOHANN CAMILO OLARTE DIAZ (http://www.geocities.com/unjohann)
 * COD 256379
 * This code could be used, modified and redistributed, provided that the above
 * copyright notice is retained.
 */

package hex_game;

import javax.swing.JOptionPane;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Representacion logica del tablero
 *
 * @author Johann Camilo Olarte Diaz(<a href="http://www.geocities.com/unjohann">Pagina Personal</a>
 * @date Feb 19, 2005
 */
public class TableroModel implements Serializable {
    /**
     * Constante que representa una casilla del jugador BLANCO o el turno del
     * jugador BLANCO
     */
    public static final int BLANCO = 1;
    
    /**
     * Constante que representa una casilla del jugador NEGRO o el turno del
     * jugador NEGRO
     */
    public static final int NEGRO = -1;
    
    /** Constante que representa una casilla vacia */
    public static final int VACIO = 0;
    
    /**
     * Cantidad de vacios en el tablero Solo est� actualizado luego de utilizar
     * la funcion jugar
     */
    private int cantvacios;
    
    /** La jugada se ejecuto correctamente (no hubo un ganador) */
    public static final int OK = 0;
    
    /** Se jugo en una posicion invalida. */
    public static final int JUGADA_INVALIDA = -1;
    
    /** Gano el jugador 1. */
    public static final int GANA_JUGADOR_1 = 1;
    
    /** Gano el jugador 2. */
    public static final int GANA_JUGADOR_2 = 2;
    
    /** Hubo un empate 2. */
    public static final int EMPATE = 3;
    
    /**El jugador envia una jugada null luego indica que se retir� del juego*/    
    public static final int RETIRO = 4;
    
    /** Representacion del tablero como una matriz. */
    protected int[][] tab;
    
    /** Numero del jugador que le corresponde jugar en la siguiente jugada. */
    private int turno;
    
    /** Tama�o del tablero este solo puede ser impar */
    private int N;
    
    /**
     * Copy constructor. Crea una nueva instancia de la clase con los mismos
     * datos de la instancia parametro.
     *
     * @param otrotab
     *            instancia a ser copiada.
     */
    public TableroModel(TableroModel otrotab) {
        turno = otrotab.turno;
        N = otrotab.N;
        cantvacios = otrotab.cantvacios;
        tab = new int[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                tab[i][j] = otrotab.tab[i][j];
            }
        }
    }
    
    /**
     * Constructor inicial
     *
     * @param turno_inicial
     *            el jugador que va a jugar primero
     */
    public TableroModel(int turno_inicial, int N) {
        if (turno_inicial != NEGRO && turno_inicial != BLANCO && N % 2 == 0) {
            System.err.println("TableroModel: argumento erroneo:"
            + turno_inicial);
        }
        this.N = N;
        cantvacios = N * N;
        turno = turno_inicial;
        tab = new int[N][N];
    }
    
    /**
     * Pone un valor en el tablero sin validar
     *
     * @param x
     *            fila
     * @param y
     *            columna
     * @param who
     *            valor a guardar (BLANCO,NEGRO)
     */
    
    protected void set(int x, int y, int who) {
        tab[x][y] = who;
    }
    
    /** Limpia el tablero */
    synchronized public void clear() {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                tab[i][j] = VACIO;
            }
        }
        cantvacios = N * N;
        turno = BLANCO;
    }
    
    /**
     * Obtiene el valor almacenado en una posicion del tablero
     *
     * @param x
     *            fila
     * @param y
     *            columna
     * @return valor almacenado (0 -> vacio, 1 -> jugador 1, 2 -> jugador 2)
     */
    synchronized public int get(int x, int y) {
        return tab[x][y];
    }
    
    /**
     * @return el numero del jugador que le corresponde jugar en la siguiente
     *         jugada.
     */
    synchronized public int getTurno() {
        return turno;
    }
    
    /**
     * Ejecuta una jugada poniendo una ficha del jugador con el turno (
     * <code> turno </code>).
     *
     * @param jugada
     */
    synchronized public int jugar(Jugada jugada) {
        return jugar(jugada.x, jugada.y);
    }
    
    /**
     * Validar jugada recibe las coordenadas de la jugada a realizar y retorna
     * si dicha jugada es v�lida o no
     *
     * @param fila
     *            fila del tablero indicada para jugar
     * @param columna
     *            columna del tablero indicada para jugar
     */
    
    synchronized public boolean validarjugada(int fila, int columna) {
        int i, j;
        if(!(fila>=0 && fila<N && columna>=0 && columna<N)) //Comprueba los indices
            return false;
        if (tab[fila][columna] != 0) {
            //la posici�n ya est� ocupada
            return false;
        } else {
            if (this.cantvacios == N * N && fila == ((N + 1) / 2 - 1)
            && columna == ((N + 1) / 2) - 1)
                //no se puede jugar en la posici�n central en la primera jugada
                return false;
            return true;
        }
    }
    
    /**
     * Realiza una jugada del jugador con el turno en la posicion
     * correspondiente. y verifica si hubo un ganador
     *
     * @param x
     *            fila
     * @param y
     *            columna
     * @return resultado de la jugada (EMPATE, GANA JUGADOR 1, GANA JUGADOR 2)
     */
    synchronized public int jugar(int x, int y) {
        //Verifica que la jugada sea v�lida
        if (validarjugada(x, y) == false)
            return JUGADA_INVALIDA;
        //Si la jugada es v�lida juega en esa posici�n
        tab[x][y] = turno;
        turno = -turno; //se cambia el turno
        cantvacios--; //se actualiza la cantidad de casillas vacias
        if (posibleganador()) {
        		if (encontrar_ruta(null))
                return -turno == BLANCO ? GANA_JUGADOR_1 : GANA_JUGADOR_2;
        		else
                return OK;
        } else {
            if (cantvacios > 0)
                return OK;
            else
                return EMPATE;
        }
    }
    
    /**
     * Clase que representa a un nodo una posible ruta ganadora
     *
     * @author Johann Camilo Olarte D�az
     */
    private class Nodoruta {
        /** jugador Jugador posible ganador y al que se le busca la ruta */
        int jugador;
        
        /** Coordenada x de el nodo */
        int fila;
        
        /** Coordenada y de el nodo */
        int columna;
        
        /**Constructor de la clase que inicializa todas las variables
         * @param jugador Jugador posible ganador y al que se le busca la ruta
         * @param x  Coordenada x del nodo
         * @param y  Coordenada y del nodo*/
        public Nodoruta(int jugador, int fila, int columna) {
            this.fila = fila;
            this.columna = columna;
            this.jugador = jugador;
        }
        
        public String toString() {
            return "(" + fila + "," + columna + ")"
            + (jugador == BLANCO ? "BLANCO" : "NEGRO");
        }
    }
    
    /**Busca una ruta que una la linea de inicio con la final para el jugador
     * que ya jug�
     * @param profundidad  Profundidad a la cual se est� buscando
     * @return Si encuentra la ruta retorna verdadero de lo contrario falso*/
    private boolean encontrar_ruta(ArrayList ruta) {
        if (ruta == null) {
            if (-turno == BLANCO) {
                for (int i = 0; i < N; i++) {
                    if (tab[0][i] == -turno) {
                        ruta = new ArrayList();
                        ruta.add(new Nodoruta(-turno, 0, i));
                        if (encontrar_ruta(ruta))
                            return true;
                    }
                }
            } else {
                for (int i = 0; i < N; i++) {
                    if (tab[i][0] == -turno) {
                        ruta = new ArrayList();
                        ruta.add(new Nodoruta(-turno, i, 0));
                        if (encontrar_ruta(ruta))
                            return true;
                    }
                }
                
            }
        } else {
            ArrayList sucesores = -turno == BLANCO ? encontrar_sucBlanco(ruta)
            : encontrar_sucNegro(ruta);
            int l = sucesores.size();
            Nodoruta prov;
            for (int i = 0; i < l; i++) {
                prov = (Nodoruta) sucesores.get(i);
                if (prov.fila == (N - 1) && prov.jugador == BLANCO)
                    return true;
                if (prov.columna == (N - 1) && prov.jugador == NEGRO)
                    return true;
                ruta.add(prov);
                if (encontrar_ruta(ruta))
                    return true;
                else
                    ruta.remove(prov);
                
            }
            return false;
        }
        return false;
    }
    
    /**
     * Busca los posibles sucesores de una ruta dada para el jugador blanco
     *
     * @param ruta
     *            Ruta actual
     * @return Lista que contiene los posibles sucesores de la ruta
     */
    private ArrayList encontrar_sucBlanco(ArrayList ruta) {
        ArrayList sucesores = new ArrayList();
        int l = ruta.size();
        Nodoruta actual = (Nodoruta) ruta.get(l - 1);
        /**Existen 6 posibles direcciones desde un hex�gono dado
         * dependiendo de su ubicacion en el tablero los sucesores
         * se a�aden o no se supone que no se le buscan sucesores a un
         * estado final*/
        //1 Caso abajo
        insertarnodo(ruta, sucesores, actual.fila + 1, actual.columna);
        
        if (actual.columna < (N - 1)) {
            //2 Caso abajo y derecha
            insertarnodo(ruta, sucesores, actual.fila + 1, actual.columna + 1);
        }
        
        if ((actual.fila) > 0) {
            if (actual.columna < (N - 1))
                //3 Caso derecha
                insertarnodo(ruta, sucesores, actual.fila, actual.columna + 1);
            if (actual.columna > 0)
                //4 Caso izquierda
                insertarnodo(ruta, sucesores, actual.fila, actual.columna - 1);
        }
        
        if (actual.fila > 1) {
            //5 Caso arriba
            insertarnodo(ruta, sucesores, actual.fila - 1, actual.columna);
            if (actual.columna > 0)
                //6 caso arriba izquierda
                insertarnodo(ruta, sucesores, actual.fila - 1,actual.columna - 1);
        }
        
        return sucesores;
    }
    
    /**
     * Busca los posibles sucesores de una ruta dada para el jugador Negro
     *
     * @param ruta
     *            Ruta actual
     * @return Lista que contiene los posibles sucesores de la ruta
     */
    private ArrayList encontrar_sucNegro(ArrayList ruta) {
        ArrayList sucesores = new ArrayList();
        int l = ruta.size();
        Nodoruta actual = (Nodoruta) ruta.get(l - 1);
        /**Existen 6 posibles direcciones desde un hex�gono dado
         * dependiendo de su ubicacion en el tablero los sucesores
         * se a�aden o no se supone que no se le buscan sucesores a un
         * estado final*/
        //1 Caso derecha
        insertarnodo(ruta, sucesores, actual.fila, actual.columna+1);
        
        if (actual.fila < (N - 1)) {
            //2 Caso abajo y derecha
            insertarnodo(ruta, sucesores, actual.fila + 1, actual.columna + 1);
        }
        
        if ((actual.columna) > 0) {
            if (actual.fila > 0)
                //3 Caso arriba
                insertarnodo(ruta, sucesores, actual.fila-1, actual.columna);
            if (actual.fila < (N - 1))
                //4 Caso abajo
                insertarnodo(ruta, sucesores, actual.fila+1, actual.columna);
        }
        
        if (actual.columna > 1) {
            //5 Caso izquierda
            insertarnodo(ruta, sucesores, actual.fila, actual.columna-1);
            if (actual.fila > 0)
                //6 caso arriba izquierda
                insertarnodo(ruta, sucesores, actual.fila - 1,actual.columna - 1);
        }
        
        return sucesores;
    }
    
    /**
     * Este m�todo inserta un nodo en la ruta pero primero verifica si el mismo
     * no existe en la ruta
     *
     * @param ruta
     *            ruta de fichas en el tablero
     * @param i
     *            fila en donde se va a insertar
     * @param j
     *            columna en donde se va a insertar
     */
    private void insertarnodo(ArrayList ruta, ArrayList sucesores, int fila,
    int columna) {
        if (tab[fila][columna] == -turno)
            if (!existenodo(ruta, fila, columna))
                sucesores.add(new Nodoruta(-turno, fila, columna));
    }
    
    /**
     * Busca un nodo en la ruta con las coordenadas fila , columna
     *
     * @param ruta
     *            Ruta en la cual va a buscar
     * @param fila
     *            del nodo a buscar
     * @param columna
     *            del nodo a buscar
     * @return retorna verdadero si el nodo se encuentra en la ruta
     */
    private boolean existenodo(ArrayList ruta, int fila, int columna) {
        int l = ruta.size();
        Nodoruta prov;
        for (int i = 0; i < l; i++) {
            prov = ((Nodoruta) ruta.get(i));
            if (prov.fila == fila && prov.columna == columna)
                return true;
        }
        return false;
    }
    
    /**
     * Verifica si existe un posible ganador de el tablero
     *
     * @return Retorna falso si no existe la posibilidad de que el jugador gane
     *         y verdadero si existe tal posibilidad
     */
    private boolean posibleganador() {
        /*
         * banderas que indican si el jugador tiene al menos una ficha en cada
         * linea de llegada
         */
        boolean lineainicio = false;
        boolean lineafinal = false;
        //	Verifica cual es el turno del que acaba de jugar
        if (-turno == BLANCO) {
            for (int i = 0; i < N; i++) {
                if (tab[0][i] == BLANCO)
                    lineainicio = true;
                if (tab[N - 1][i] == BLANCO)
                    lineafinal = true;
            }
        } else {
            for (int i = 0; i < N; i++) {
                if (tab[i][0] == NEGRO)
                    lineainicio = true;
                if (tab[i][N - 1] == NEGRO)
                    lineafinal = true;
            }
        }
        return lineainicio & lineafinal;
    }
    
    /**
     * Representacion en string del tablero
     */
    synchronized public String toString() {
        StringBuffer result = new StringBuffer();
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                result.append(tab[i][j]);
            }
            result.append("\n");
        }
        return result.toString();
    }
    
    /** @return retorna el N que es el lado del tablero */
    public int getN() {
        return N;
    }
    
    /**
     * Permite probar la clase
     *
     * @param args
     *            no usado
     */
    public static void main(String[] args) throws Exception {
        int x;
        int y;
        String valor;
        TableroModel model = new TableroModel(1, 7);
        model.jugar(0, 0);//BLANCO
        model.jugar(6, 6);//NEGRO
        model.jugar(1, 1);//BLANCO
        model.jugar(5, 6);//NEGRO
        model.jugar(2, 1);//BLANCO
        model.jugar(4, 6);//NEGRO
        model.jugar(3, 1);//BLANCO
        model.jugar(3, 6);//NEGRO
        model.jugar(4, 1);//BLANCO
        model.jugar(2, 6);//NEGRO
        model.jugar(5, 1);//BLANCO
        model.jugar(1, 6);//NEGRO
        
        do {
            valor = JOptionPane.showInputDialog(null, "Introduzca la fila "
            + "Turno: " + (model.turno == BLANCO ? "BLANCO" : "NEGRO"));
            x = Integer.parseInt(valor);
            valor = JOptionPane.showInputDialog(null, "Introduzca la columna"
            + "Turno: " + (model.turno == BLANCO ? "BLANCO" : "NEGRO"));
            y = Integer.parseInt(valor);
            if (model.jugar(x, y) == JUGADA_INVALIDA)
                JOptionPane.showMessageDialog(null, "JUGADA INVALIDA");
            JOptionPane.showMessageDialog(null, "TABLERO\n" + model.toString());
        } while (true);
        
    }
    
}