/*
 * Project: Hex
 * File:    AgentAuto.java
 * Created on Feb 19, 2005
 * 
 * Copyright 2005 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y 
 * cuando se mantenga el anterior aviso de Copyright.
 * MODIFICADO POR JOHANN CAMILO OLARTE DIAZ 
 * COD 256379
 * This code could be used, modified and redistributed, provided that the above 
 * copyright notice is retained. 
 */
 
package hex_game;
/**
 * Esta clase sirve como base para escribir su propio codigo. Esta clase es 
 * la unica clase que, en principio, se debe modificar.
 * @author Fabio Gonzalez, Johann Camilo Olarte Diaz
 * @date Feb 19, 2005
 */
public class AgentAuto {	
	/**
	 * Efectua la jugada del agente basada en el estado actual del tablero. <br> 
	 * Tenga en cuenta que el tablero tiene la informacion sobre la ficha 
	 * que esta jugando actualmente. <b>Aqui debe ir su codigo</b>. 
         * Este agente busca secuencialmente la primera jugada disponible y la retorna
	 * @param tab objeto representando el estado actual del tablero
	 * @return La jugada a efectuar.
	 */
	public Jugada calculaJugada(TableroModel tab){
		int l=tab.getN();
		for(int i=0;i<l;i++){
			for(int j=0;j<l;j++){
				if (tab.validarjugada(i,j)){
					return new Jugada(i,j);
				}
			}			
		}
		return new Jugada(-1,-1);
	}

}//fin de la clase