/*
 * Project: Hex
 * File:    TanbleroView.java
 * Created on Mar 31, 2004
 *
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y
 * cuando se mantenga el anterior aviso de Copyright.
 * Modificado por Johann Camilo Olarte D�az
 * COD 256379 Feb 19 2005
 * This code could be used, modified and redistributed, provided that the above
 * copyright notice is retained.
 */
package hex_game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

/**
 * Representacion grafica del tablero.
 *  @author Fabio Gonzalez, Daniel Penagos, Johann Camilo Olarte Diaz(<a href="http://www.geocities.com/unjohann">Pagina Personal</a>
 *  @date Feb 19, 2005
 */
public class TableroJugar extends JPanel {
    
    TableroModel tabModel;
    Image imficharoja;
    Image imfichaazul;
    private boolean existejugada;
    private final int ANCHOHEX=30;
    private final int ALTOHEX=20;
    public final int ANCHOTABLERO;
    public final int ALTOTABLERO;
    private final int lado;
    private final int CORRIMIENTOX=ALTOHEX;
    private final int CORRIMIENTOY=ANCHOHEX/3;
    private static final int RadioClick=5;
    private int jug_fila;
    private int jug_column;
    private static final Color ColorFondo=new Color(0.9f,0.8f,0.9f,1f);
    private static final Color ColorNegras=new Color(0f,0f,0f,1f);
    private static final Color ColorBlancas=new Color(1f,1f,1f,1f);
    
    /**Construye una instancia que muestra graficamente el Modelo
     * del Tablero enviado como argumento. Adem�s permite que un usuario
     * haga click en la superficie del tablero y se tengan disponibles la jugada
     * del usuario.
     * @param tm TableroModel a pintar*/
    public TableroJugar(TableroModel tm){
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clickTablero(evt);
            }
        });
        tabModel = tm;
        lado=tabModel.getN();
        ANCHOTABLERO=ANCHOHEX*lado+(lado-1)*(ANCHOHEX/3);
        ALTOTABLERO=ALTOHEX*lado;
        existejugada=false;
        jug_fila=-1;
        jug_column=-1;
    }
    /**Procedimiento que averigua donde hizo click el usuario*/
    private void clickTablero(java.awt.event.MouseEvent evt) {
        int x=evt.getX();
        int y=evt.getY();
        int coordy;
        int coordx;
        int i = 0;
        int fila;
        int column;
        for (fila = 0; fila < lado; fila++) {
            coordx=ANCHOTABLERO/2-((ANCHOHEX*2)/3)*(fila)+CORRIMIENTOX;
            coordy=(fila+1)*(ALTOHEX/2)+CORRIMIENTOY;
            for (column = 0; column < lado; column++) {
                if(Math.sqrt(Math.pow(x-coordx,2)+Math.pow(y-coordy,2))<RadioClick){
                    if(tabModel.validarjugada(fila,column)){
                        existejugada=true;
                        jug_fila=fila;
                        jug_column=column;
                    }
                }
                coordy+=ALTOHEX/2;
                coordx+=(ANCHOHEX*2)/3;
            }
        }
    }
    /**Asigna el TableroModel que sera visualizado
     * @param tm modelo*/
    public void setModel(TableroModel tm){
        tabModel = tm;
        repaint();
    }
    /**Dibuja un hex�gono en el tablero dependiendo de sus coordenadas
     * @param g Objeto Graphics en el cual se va a dibujar
     * @param x Coordenada x del hexagono
     * @param y Coordenada y del hex�gono*/
    public void dibujahexagono(Graphics g,int x, int y){
        int xcoord[]=new int[6];
        int ycoord[]=new int[6];
        xcoord[0]=x-ANCHOHEX/2;
        xcoord[1]=x-(ANCHOHEX)/6;
        xcoord[2]=x+(ANCHOHEX)/6;
        xcoord[3]=x+ANCHOHEX/2;
        xcoord[4]=x+ANCHOHEX/6;
        xcoord[5]=x-ANCHOHEX/6;
        ycoord[0]=y;
        ycoord[1]=y-ALTOHEX/2;
        ycoord[2]=y-ALTOHEX/2;
        ycoord[3]=y;
        ycoord[4]=y+ALTOHEX/2;
        ycoord[5]=y+ALTOHEX/2;
        g.fillPolygon(xcoord,ycoord,6);
        g.setColor(Color.black);
        g.drawPolygon(xcoord,ycoord,6);
    }
    /**Dibuja el rombo del tablero que rodea el tablero
     *@param g Objeto Graphics en el cual se va a dibujar
     *@param tam tama�o del rombo*/
    private void dibujaRombo(Graphics g){
        int xcoord[]=new int[4];
        int ycoord[]=new int[4];
        xcoord[0]=0;
        xcoord[1]=(ANCHOTABLERO/2+CORRIMIENTOX);
        xcoord[2]=ANCHOTABLERO+2*CORRIMIENTOX;
        xcoord[3]=(ANCHOTABLERO/2+CORRIMIENTOX);
        ycoord[0]=(ALTOTABLERO/2+CORRIMIENTOY);
        ycoord[1]=0;
        ycoord[2]=ALTOTABLERO/2+CORRIMIENTOY;
        ycoord[3]=(ALTOTABLERO+2*CORRIMIENTOY);
        g.setColor(ColorNegras);
        g.fillPolygon(xcoord,ycoord,4);
        xcoord[0]=(ANCHOTABLERO/2+CORRIMIENTOX);
        xcoord[1]=(ANCHOTABLERO/2+CORRIMIENTOX);
        xcoord[2]=ANCHOTABLERO+2*CORRIMIENTOX-1;
        xcoord[3]=ANCHOTABLERO+CORRIMIENTOX;
        ycoord[0]=CORRIMIENTOY;
        ycoord[1]=1;
        ycoord[2]=ALTOTABLERO/2+CORRIMIENTOY;
        ycoord[3]=ALTOTABLERO/2+CORRIMIENTOY;
        g.setColor(ColorBlancas);
        g.fillPolygon(xcoord,ycoord,4);
        xcoord[0]=CORRIMIENTOX;
        xcoord[1]=1;
        xcoord[2]=(ANCHOTABLERO/2+CORRIMIENTOX);
        xcoord[3]=(ANCHOTABLERO/2+CORRIMIENTOX);
        ycoord[0]=(ALTOTABLERO/2+CORRIMIENTOY);
        ycoord[1]=(ALTOTABLERO/2+CORRIMIENTOY);
        ycoord[2]=(ALTOTABLERO+2*CORRIMIENTOY)-1;
        ycoord[3]=(ALTOTABLERO+CORRIMIENTOY);
        g.fillPolygon(xcoord,ycoord,4);
    }
    /**Dibuja el tablero del juego con sus respectivas fichas*/
    public void paintComponent(Graphics g) {
        dibujaRombo(g);
        g.setColor(ColorFondo);
        int coordy;
        int coordx;
        int i = 0;
        int fila;
        int column;
        for (fila = 0; fila < lado; fila++) {
            coordx=ANCHOTABLERO/2-((ANCHOHEX*2)/3)*(fila)+CORRIMIENTOX;
            coordy=(fila+1)*(ALTOHEX/2)+CORRIMIENTOY;
            for (column = 0; column < lado; column++) {
                dibujahexagono(g,coordx, coordy);
                switch (tabModel.get(fila, column)) {
                    case TableroModel.NEGRO : //ficha negra
                        g.setColor(ColorNegras);
                        g.fillOval(coordx-ANCHOHEX/4,coordy-ALTOHEX/4, ANCHOHEX/2, ALTOHEX/2);
                        break;
                    case TableroModel.BLANCO: //ficha blanca
                        g.setColor(ColorBlancas);
                        g.fillOval(coordx-ANCHOHEX/4,coordy-ALTOHEX/4, ANCHOHEX/2, ALTOHEX/2);
                        break;
                }
                g.setColor(ColorFondo);
                coordy+=ALTOHEX/2;
                coordx+=(ANCHOHEX*2)/3;
            }
        }
    }
    /** Retorna un boolean que indica si ya existe una jugada disponible
     *@return Booleano que indica que ya existe una jugada disponible
     */
    public boolean existeJugada(){
        return existejugada;
    }
    
    /**Retorna la fila de la jugada realizada
     @return Fila con la jugada realizada*/
    public int getFilaJugada(){
        return jug_fila;
    }
    
    /**Retorna la Columna de la jugada realizada
     @return Columna con la jugada realizada*/
    public int getColumnJugada(){
        return jug_column;
    }
    /**
     * Permite probar el componente
     * @param args no se usa
     */
    public static void main(String[] args)throws Exception {
        JFrame jf = new JFrame("Test TableroView");
        jf.getContentPane().setLayout(new BorderLayout());
        TableroModel tm = new TableroModel(1,7);
        tm.jugar(1,1);
        tm.jugar(2,2);
        tm.jugar(3,3);
        tm.jugar(5,5);
        jf.getContentPane().add(new TableroJugar(tm));
        jf.setSize(200,200);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
    
}

