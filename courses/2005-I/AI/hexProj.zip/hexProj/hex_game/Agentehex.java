/*
 * Project: Hex
 * File:    Agentehex.java
 * Created on Mar 31, 2004
 *
 * Copyright 2005 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y
 * cuando se mantenga el anterior aviso de Copyright.
 * COD 256379 Feb 19 2005
 * This code could be used, modified and redistributed, provided that the above
 * copyright notice is retained.
 */

package hex_game;
//import java.util.ArrayList;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.WindowConstants;
/**
 *  Esta clase sirve como base para escribir su propio codigo. Esta clase es
 * la unica clase que, en principio, se debe modificar.
 *  @author Fabio Gonzalez, Johann Camilo Olarte D�az
 *  @date Feb 19, 2004
 */
public class Agentehex {
    private TableroJugar tablero;
    private JFrame jf;
    public Agentehex(){
        jf = new JFrame("Ingrese su jugada");
        jf.getContentPane().setLayout(new BorderLayout());
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
    /**
     * Efectua la jugada del agente basada en el estado actual del tablero. <br>
     * Tenga en cuenta que el tablero tiene la informacion sobre la ficha
     * que esta jugando actualmente.Este agente utiliza la clase TableroJugar para obtener
     * la jugada de modo interactivo.
     * @param tab objeto representando el estado actual del tablero
     * @return La jugada a efectuar.
     */
    public Jugada calculaJugada(TableroModel tab){
        int i;
        int j;
        int n=tab.getN();
        tablero=new TableroJugar(tab);
        jf.setTitle("Ingrese su jugada, Turno:  "+(tab.getTurno()==TableroModel.BLANCO?"blancas":"negras"));
        jf.getContentPane().removeAll();
        jf.getContentPane().add(tablero);
        jf.getContentPane().repaint();
        jf.setSize(tablero.ANCHOTABLERO+50,tablero.ALTOTABLERO+50);
        jf.setVisible(true);
        //Espera mientras la ventana tiene alguna jugada v�lida
        while(!tablero.existeJugada()){            
            try{
                Thread.sleep(100);
            }catch(Exception e){;}
        }
        tab.jugar(tablero.getFilaJugada(),tablero.getColumnJugada());
        Jugada jug_ret=new Jugada(tablero.getFilaJugada(),tablero.getColumnJugada());
        tablero=new TableroJugar(tab);
        jf.setTitle("Espere un momento, Turno: "+(tab.getTurno()==TableroModel.BLANCO?"blancas":"negras"));
        jf.getContentPane().removeAll();        
        jf.getContentPane().add(tablero);
        jf.getContentPane().repaint();
        jf.setSize(tablero.ANCHOTABLERO+50,tablero.ALTOTABLERO+50);
        jf.setVisible(true);
        //retorna la jugada que escogi� el cliente
        return jug_ret;
    }
    
}//fin de la clase