/*
 * Project: Hex
 * File:    ServidorModel.java
 * Created on Mar 29, 2004
 *
 * Copyright 2004 Fabio Gonzalez
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y
 * cuando se mantenga el anterior aviso de Copyright.
 *
 * This code could be used, modified and redistributed, provided that the above
 * copyright notice is retained.
 */

package hex_game;

/**
 * Maneja la parte logica del servidor (@see hexgame.ServidorGUI)
 *  @author Fabio Gonzalez, Johann Camilo Olarte Diaz
 *  @date Mar 29, 2004
 */
public class ServidorModel{
    ServidorComm comm;
    ServidorGUI gui;
    TableroModel tab;
    String jug1,jug2;
    
    /**Crea un nuevo servidor 
     @param Comm Este objeto es el encargado de escuchar y enviar peticiones a trav�s
     de sockets con los clientes
     @param ServidorGUI objeto que maneja la interfaz gr�fica
     @param n Tama�o del tablero en el cual se va a jugar*/
    public ServidorModel(ServidorComm sc,ServidorGUI sg,int n){
        comm=sc;
        gui=sg;
        tab=new TableroModel(1,n);
    }
    /**Arranca un juego entre 2 oponentes dejando el tablero vacio*/
    public void comenzarJuego(String j1, String j2){
        jug1 = j1;
        jug2 = j2;
        tab.clear();
    }
    
    /**Solicita el resultado de una jugada al objeto comm
     @return Resultado de jugar (Gana jugador 1, Gana jugador 2, Empate, Retiro)
     @see hexgame.TableroModel*/
    public int jugar(){
        String jugador;
        if(tab.getTurno()==1){
            jugador=jug1;
        }else{
            jugador=jug2;
        }
        Jugada jugada = comm.obtenerJugadaSiguiente(jugador,tab);
        if(jugada!=null){
            int result = tab.jugar(jugada);
            return result;
        }else{
            comm.isJugadorValido(jugador);
            return TableroModel.RETIRO;
        }
    }
    
    /**Pregunta si el jugador es v�lido o no al objeto comm
     * @return booleano que indica si el jugador es v�lido o no*/
    public boolean isJugadorValido(String nomJugador){
        return comm.isJugadorValido(nomJugador);
    }
    /** Retorna el tablero actual del juego
     * @return Objeto con el tablero actual
     */
    public TableroModel getTab() {
        return tab;
    }
    
}
