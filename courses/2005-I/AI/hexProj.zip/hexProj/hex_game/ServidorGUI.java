/*
 * Project: Hex
 * File:    Servidor.java
 * Created on Mar 28, 2004
 * Modifica
 * Copyright 2004 Fabio Gonzalez, Daniel Penagos Modificado por Johann Camilo Olarte
 * Este codigo puede ser libremente usado, modificado y distribuido, siempre y
 * cuando se mantenga el anterior aviso de Copyright.
 *
 * This code could be used, modified and redistributed, provided that the above
 * copyright notice is retained.
 */
package hex_game;

import java.awt.*;
import java.awt.event.ActionEvent;

import javax.swing.*;

/**
 * Implementacion del servidor del juego Hex. Recibe conexiones
 *  desde clientes posiblemente en una ubicacion remota.
 * (@see hex_game.Client ).
 *  Muestra el tablero graficamente y permite realizar una partida entre 2
 * clientes que se hayan conectado previamente.
 *  @author Fabio Gonzalez, Daniel Penagos, Modificado por Johann Camilo Olarte Diaz(<a href="http://www.geocities.com/unjohann">Pagina Personal</a>
 *  @date Feb 19, 2005
 *
 */
public class ServidorGUI extends JFrame implements ConnListener{
    
    /**Cadena con el nombre del jugador 1*/
    private String jug1;
    /**Cadena con el nombre del jugador 2*/
    private String jug2;
    /**Objeto que maneja las reglas del juego como turno, y quien est� jugando*/
    private ServidorModel modelo;
    /**Panel que visualiza el tablero en el servidor*/
    TableroView view;
    /**Objeto que maneja las comunicaciones con los clientes*/
    ServidorComm communicat;
    /**Numero de jugadas realizadas en un juego*/
    int numjugadas=0;
    /**componentes graficos*/
    BorderLayout borde = new BorderLayout();
    JSplitPane jSplitPane1 = new JSplitPane();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTextArea jTAMensajes = new JTextArea();
    JPanel jPanelControles = new JPanel();
    Box boxJugadores;
    BorderLayout bordeSplit = new BorderLayout();
    JLabel jLabelJug2 = new JLabel();
    JComboBox jCBJugador1 = new JComboBox();
    JButton jBJugar = new JButton();
    JButton jBJugarCont = new JButton();
    JLabel jLabelJug1 = new JLabel();
    JComboBox jCBJugador2 = new JComboBox();
    JButton jBComenzar = new JButton();
    boolean flag;
    float[] maxTime;
    float[] meanTime;
    public ServidorGUI(int n){
        communicat = new ServidorComm();
        communicat.addConnListener(this);
        modelo = new ServidorModel(communicat,this,n);
        try {
            communicat.arrancarServidor();
            jbInit();
            setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            setTitle("Hex");
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    /**Crea la interfaz del servidor e inicializa todos los controles*/
    private void jbInit() throws Exception {
        view = new TableroView(modelo.getTab());
        boxJugadores = Box.createVerticalBox();
        jTAMensajes.setText("");
        jPanelControles.setLayout(bordeSplit);
        jLabelJug2.setText("Jug 2 (rojo)");
        jBJugar.setText("Jugar...");
        jBJugar.setEnabled(false);
        jBJugarCont.setText("Jugar Cont...");
        jBJugarCont.setEnabled(false);
        jBJugar.addActionListener(new Servidor_jBJugar_actionAdapter(this));
        jBJugarCont.addActionListener(new Servidor_jBJugarCont_actionAdapter(this));
        jLabelJug1.setText("Jug 1 (blanco)");
        jBComenzar.setText("Comenzar");
        jBComenzar.addActionListener(new Servidor_jBComenzar_actionAdapter(this));
        jSplitPane1.add(jScrollPane1, JSplitPane.BOTTOM);
        jSplitPane1.add(jPanelControles, JSplitPane.TOP);
        jPanelControles.add(boxJugadores, BorderLayout.EAST);
        jPanelControles.add(view, BorderLayout.CENTER);
        jScrollPane1.getViewport().add(jTAMensajes, null);
        boxJugadores.add(jLabelJug1,null);
        boxJugadores.add(jCBJugador1, null);
        boxJugadores.add(jLabelJug2, null);
        boxJugadores.add(jCBJugador2, null);
        boxJugadores.add(jBComenzar, null);
        boxJugadores.add(jBJugar, null);
        boxJugadores.add(jBJugarCont, null);
        this.getContentPane().setLayout(borde);
        this.getContentPane().add(jSplitPane1, BorderLayout.CENTER);
        jSplitPane1.setOrientation(JSplitPane.VERTICAL_SPLIT);
        jSplitPane1.setDividerLocation(259);
    }
    /**Arranca un juego entre 2 jugadores primero revisa si los jugadores son 
     *validos si no son v�lidos los retira del juego*/
    void jBComenzar_actionPerformed(ActionEvent e) {
        jug1 = (String) jCBJugador1.getSelectedItem();
        jug2 = (String) jCBJugador2.getSelectedItem();
        
        if(modelo.isJugadorValido(jug1)){
            if(modelo.isJugadorValido(jug2)){
                adicionaMensaje("Comenzando juego: "+jug1+" vs "+jug2+"\n");
                modelo.comenzarJuego(jug1,jug2);
                numjugadas=0;
                jBJugar.setEnabled(true);
                jBJugarCont.setEnabled(true);
            }else{
                if(jCBJugador2.getSelectedIndex()>=0){
                    jCBJugador1.removeItemAt(jCBJugador2.getSelectedIndex());
                    jCBJugador2.removeItemAt(jCBJugador2.getSelectedIndex());
                }
                adicionaMensaje("El jugador 2 no esta disponible o cerro la conexi�n\n");
            }
        }else{
            if(jCBJugador1.getSelectedIndex()>=0){
                jCBJugador2.removeItemAt(jCBJugador1.getSelectedIndex());
                jCBJugador1.removeItemAt(jCBJugador1.getSelectedIndex());
            }
            adicionaMensaje("El jugador 1 no esta disponible o cerro la conexi�n\n");
        }
        
        view.repaint();
    }
    /**Realiza una jugada en el tablero pide el resultado de la jugada al objeto modelo
     * que se encarga de manejar la l�gica del juego*/
    void jBJugar_actionPerformed(ActionEvent e) {
        numjugadas++;
        long timeIni = System.currentTimeMillis();
        int result = modelo.jugar();
        long timeFin = System.currentTimeMillis();
        switch (result){
            case TableroModel.JUGADA_INVALIDA:
                adicionaMensaje("Jugada Invalida!!\n");
                break;
            case TableroModel.GANA_JUGADOR_1:
                adicionaMensaje("Gana jugador 1: "+jug1+"\n");
                jBJugar.setEnabled(false);
                jBJugarCont.setEnabled(false);
                break;
            case TableroModel.GANA_JUGADOR_2:
                adicionaMensaje("Gana jugador 2: "+jug2+"\n");
                jBJugar.setEnabled(false);
                jBJugarCont.setEnabled(false);
                break;
            case TableroModel.OK :
                adicionaMensaje("Jug "+
                ((modelo.getTab().getTurno()+1)/2+1)+
                ":"+
                (modelo.getTab().getTurno() == -1 ? jug1 : jug2)
                + ": "
                + (timeFin - timeIni)
                + " msec\n");
                break;
            case TableroModel.EMPATE:
                adicionaMensaje("Empate\n");
                jBJugar.setEnabled(false);
                break;
            case TableroModel.RETIRO:
                adicionaMensaje("El jugador "+(modelo.getTab().getTurno()==TableroModel.BLANCO?"Jugador 1":"Jugador 2")+" se retir� del juego\n");
                jBJugar.setEnabled(false);
        }
        view.repaint();
    }
    
    /**Realiza un juego continuo entre los dos jugadores seleccionados, arranca un hilo que es el 
     * que se encarga de pedir las jugadas al modelo*/
    void jBJugarCont_actionPerformed(ActionEvent e) {
        flag = true;
        maxTime = new float[2];
        meanTime = new float[2];
        Runnable hilo = new Runnable() {
            public void run() {
                while (flag) {
                    numjugadas++;
                    int turno = modelo.getTab().getTurno();
                    long timeIni = System.currentTimeMillis();
                    int result = modelo.jugar();
                    long timeFin = System.currentTimeMillis();
                    maxTime[turno==TableroModel.BLANCO?0:1] =
                    Math.max(maxTime[turno==TableroModel.BLANCO?0:1], timeFin - timeIni);
                    meanTime[turno==TableroModel.BLANCO?0:1] += (timeFin - timeIni);
                    switch (result) {
                        case TableroModel.JUGADA_INVALIDA :
                            adicionaMensaje("Jugada Invalida!!\n");
                            flag = false;
                            break;
                        case TableroModel.GANA_JUGADOR_1 :
                            adicionaMensaje("Gana jugador 1: " + jug1 + "\n");
                            flag = false;
                            jBJugar.setEnabled(false);
                            jBJugarCont.setEnabled(false);
                            break;
                        case TableroModel.GANA_JUGADOR_2 :
                            adicionaMensaje("Gana jugador 2: " + jug2 + "\n");
                            flag = false;
                            jBJugar.setEnabled(false);
                            jBJugarCont.setEnabled(false);
                            break;
                        case TableroModel.OK :
                            adicionaMensaje(
                            (modelo.getTab().getTurno() == TableroModel.NEGRO ? jug1 : jug2)
                            + ": "
                            + (timeFin - timeIni)
                            + " msec\n");
                            break;
                        case TableroModel.EMPATE :
                            adicionaMensaje("Empate\n");
                            flag=false;
                            jBJugar.setEnabled(false);
                            jBJugarCont.setEnabled(false);
                            break;
                        case TableroModel.RETIRO:
                            adicionaMensaje("El jugador "+(modelo.getTab().getTurno()==TableroModel.BLANCO?"Jugador 1":"Jugador 2")+" se retir� del juego\n");
                            flag=false;
                            jBJugar.setEnabled(false);
                            jBJugarCont.setEnabled(false);
                    }
                    view.repaint();
                }
                meanTime[0] /= numjugadas / 2;
                meanTime[1] /= numjugadas / 2;
                adicionaMensaje(jug1+ ": max="+ maxTime[0]+ "msec , promedio="
                + meanTime[0]+ " sec\n");
                adicionaMensaje(jug2+ ": max="+ maxTime[1]+ "msec , promedio="
                + meanTime[1]+ " sec\n\n");
            }
        };
        new Thread(hilo).start();
    }
    
    
    
    /**Agrega un mensaje al area de texto
     * @param m Mensaje a ser adicionado*/
    public void adicionaMensaje(String m){
        jTAMensajes.append(m);
        JScrollBar sb =	jScrollPane1.getVerticalScrollBar();
        sb.setValue(sb.getMaximum());
    }
    
    /**Adiciona un cliente a los controles*/
    private void addCliente(String name){
        jTAMensajes.append("****************\nNuevo cliente:"+name+"\n****************\n");
        jCBJugador1.addItem(name);
        jCBJugador2.addItem(name);
    }
    
    /**Procedimiento principal que corre el servidor*/
    public static void main(String[] args) throws HeadlessException {
        ServidorGUI serv = new ServidorGUI(Integer.parseInt(args[0]));
        serv.setSize(500,500);
        serv.setVisible(true);
        serv.setTitle("Hex "+args[0]);
    }
    
        /* (non-Javadoc)
         * @see hex_game.ConnListener#nuevaConexion(java.lang.String)
         */
    public void nuevaConexion(String name) {
        addCliente(name);
    }
    
        /* (non-Javadoc)
         * @see hex_game.ConnListener#removerConexion(java.lang.String)
         */
    public void removerConexion(String name) {
        
    }
    
}
/**Clases auxiliares para manejar eventos*/
class Servidor_jBComenzar_actionAdapter implements java.awt.event.ActionListener {
    ServidorGUI adaptee;
    
    Servidor_jBComenzar_actionAdapter(ServidorGUI adaptee) {
        this.adaptee = adaptee;
    }
    public void actionPerformed(ActionEvent e) {
        adaptee.jBComenzar_actionPerformed(e);
    }
}

class Servidor_jBJugar_actionAdapter implements java.awt.event.ActionListener {
    ServidorGUI adaptee;
    
    Servidor_jBJugar_actionAdapter(ServidorGUI adaptee) {
        this.adaptee = adaptee;
    }
    public void actionPerformed(ActionEvent e) {
        adaptee.jBJugar_actionPerformed(e);
    }
}

class Servidor_jBJugarCont_actionAdapter implements java.awt.event.ActionListener {
    ServidorGUI adaptee;
    
    Servidor_jBJugarCont_actionAdapter(ServidorGUI adaptee) {
        this.adaptee = adaptee;
    }
    public void actionPerformed(ActionEvent e) {
        adaptee.jBJugarCont_actionPerformed(e);
    }
}

