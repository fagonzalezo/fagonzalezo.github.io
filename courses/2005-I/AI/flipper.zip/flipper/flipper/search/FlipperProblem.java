/*
 * Created on Mar 11, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package flipper.search;

import java.util.ArrayList;
import java.util.List;

import aima.search.framework.*;

/**
 * 
 *  @author Fabio Gonzalez
 *  @date Mar 11, 2004 
 */
public class FlipperProblem extends Problem {

	public FlipperProblem(boolean[][] configuration) {
		super(new FlipperBoard(configuration),
				new FuncSucesores(),new EstadoObjetivo());
	}

}

class FuncSucesores implements SuccessorFunction{

	/* (non-Javadoc)
	 * @see aima.search.framework.SuccessorFunction#getSuccessors(java.lang.Object)
	 */
	public List getSuccessors(Object arg0) {
		ArrayList result = new ArrayList();
		
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				FlipperBoard state = new FlipperBoard();
				state.setBoard((FlipperBoard)arg0);
				state.hit(i,j);
				result.add(new Successor("("+i+","+j+")",state));
			}
		}
		return result;
	}
}

class EstadoObjetivo implements GoalTest{

	/* (non-Javadoc)
	 * @see aima.search.framework.GoalTest#isGoalState(java.lang.Object)
	 */
	public boolean isGoalState(Object arg0) {
		return arg0.equals(
				new FlipperBoard(
						new boolean[][]{{false,false,false},
										{false,true,false},
										{false,false,false}}));
	}
	
}