/*
 * Created on Mar 11, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package flipper.search;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import aima.search.uninformed.BreadthFirstSearch;
import aima.search.uninformed.DepthFirstSearch;
import aima.search.uninformed.IterativeDeepeningSearch;
import aima.search.framework.GraphSearch;
/**
 * 
 *  @author Fabio Gonzalez
 *  @date Mar 11, 2004 
 */
public class Demo {

	public static void main(String[] args) throws Exception {
		FlipperProblem p = new FlipperProblem(new boolean[][]
			{{true,false,false},{true,true,false},{false,false,false}});
		FlipperSearchAgent a = new FlipperSearchAgent(p,new IterativeDeepeningSearch());
		printInstrumentation(a.getInstrumentation());
		printActions(a.getActions());
	}
	
	private static void printInstrumentation(Properties properties) {
		Iterator keys = properties.keySet().iterator();
		while (keys.hasNext()) {
			String key = (String) keys.next();
			String property = properties.getProperty(key);
			System.out.println(key + " : " + property);
		}

	}

	private static void printActions(List actions) {
		for (int i = 0; i < actions.size(); i++) {
			String action = (String) actions.get(i);
			System.out.println(action);
		}
	}
}

