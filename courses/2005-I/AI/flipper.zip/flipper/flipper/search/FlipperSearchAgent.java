/*
 * Created on Mar 11, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package flipper.search;

import java.util.ArrayList;

import aima.search.uninformed.DepthFirstSearch;
import aima.search.framework.Node;
import aima.search.framework.Problem;
import aima.search.framework.SearchAgent;
import aima.search.framework.Search;

/**
 * 
 *  @author Fabio Gonzalez
 *  @date Mar 11, 2004 
 */
public class FlipperSearchAgent extends SearchAgent {

	
	/**
	 * @throws Exception
	 * 
	 */
	public FlipperSearchAgent(FlipperProblem p,Search s) throws Exception{
		super(p,s);
	}

	

	/* (non-Javadoc)
	 * @see aima.search.SearchAgent#nodesToActions(java.util.ArrayList)
	 */
	public ArrayList nodesToActions(ArrayList nodes) {
		ArrayList retVal= new ArrayList();
		if (nodes.size() > 0){
//			nodes.remove(0); //remove initial state node
			for (int i=0;i<nodes.size();i++){
				Node n = (Node)nodes.get(i);
			   FlipperBoard board = (FlipperBoard)n.getState();
				 retVal.add(board.toString());
			}
		}
		return retVal;
	}

}
