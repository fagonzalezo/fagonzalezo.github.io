package flipper.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: UN</p>
 * @author Fabio Gonzalez
 * @version 1.0
 */

public class MainFrame extends JFrame {
  JPanel contentPane;
  JToolBar jToolBar = new JToolBar();
  JLabel statusBar = new JLabel();
  BorderLayout borderLayout1 = new BorderLayout();
  JButton StartButton = new JButton();
  JPanel jPanel1 = new JPanel();
  GridLayout gridLayout1 = new GridLayout(3,3);
  JButton[][] buttons = new JButton[3][3];
  class ButtonAction implements ActionListener{
    int x,y;
    public ButtonAction(int x,int y){
      this.x = x;
      this.y = y;
    }
    public void actionPerformed(ActionEvent evt){
      System.out.println("x:"+x+"y:"+y);
      flip(x,y);
      if (x==1){
        flip(0, y);
        flip(2, y);
      }
      if (y==1){
        flip(x, 0);
        flip(x, 2);
      }
      if (x!=1 && y!=1){
        flip(x,1);
        flip(1,y);
      }
    }
    private void flip(int i, int j){
      if(buttons[i][j].getText().equals("*")){
        buttons[i][j].setText("X");
      }else{
        buttons[i][j].setText("*");
      }
    }
  }
  //Construct the frame
  public MainFrame() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
      for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
          buttons[i][j] = new JButton("*");
          jPanel1.add(buttons[i][j]);
          buttons[i][j].addActionListener(new ButtonAction(i,j));
        }
      }
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  //Component initialization
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(borderLayout1);
    this.setSize(new Dimension(400, 300));
    this.setTitle("Flipper");
    statusBar.setText(" ");
    StartButton.setText("Start");
    StartButton.addActionListener(new MainFrame_StartButton_actionAdapter(this));
    jPanel1.setLayout(gridLayout1);
    contentPane.add(jToolBar, BorderLayout.NORTH);
    jToolBar.add(StartButton, null);
    contentPane.add(statusBar, BorderLayout.SOUTH);
    contentPane.add(jPanel1,  BorderLayout.CENTER);
  }

  //File | Exit action performed
  public void jMenuFileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }

  //Help | About action performed
  public void jMenuHelpAbout_actionPerformed(ActionEvent e) {
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }

  void StartButton_actionPerformed(ActionEvent e) {
    for(int i=0;i<3;i++){
      for (int j = 0; j < 3; j++) {
        if (Math.random() >= 0.5) {
          buttons[i][j].setText("X");
        }
        else {
          buttons[i][j].setText("*");
        }
      }
    }
  }
}

class MainFrame_StartButton_actionAdapter implements java.awt.event.ActionListener {
  MainFrame adaptee;

  MainFrame_StartButton_actionAdapter(MainFrame adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.StartButton_actionPerformed(e);
  }
}
